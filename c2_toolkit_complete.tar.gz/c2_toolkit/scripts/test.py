#!/usr/bin/env python3
"""
ShadowC2 Test Script
Тестирование основных функций toolkit
"""

import os
import sys
import subprocess
import json
import hashlib
from pathlib import Path
import platform

class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

class ShadowC2Tester:
    def __init__(self):
        self.project_root = Path(__file__).parent.parent
        self.bin_dir = self.project_root / "bin"
        self.server_dir = self.project_root / "server"
        
    def test_file_structure(self):
        """Тестирование структуры файлов"""
        print(f"\n{Colors.YELLOW}[*] Testing file structure...{Colors.ENDC}")
        
        required_files = [
            "CMakeLists.txt",
            "src/stager.cpp",
            "src/loader.cpp",
            "src/beacon.cpp",
            "src/persistence.cpp",
            "src/main.cpp",
            "src/shadow.h",
            "src/CMakeLists.txt",
            "server/shadow_server.py",
            "server/requirements.txt",
            "scripts/build.py",
            "scripts/run_server.py",
            "docs/usage.md",
            "README.md"
        ]
        
        all_exist = True
        for file_path in required_files:
            full_path = self.project_root / file_path
            if full_path.exists():
                print(f"{Colors.GREEN}[+] {file_path} exists{Colors.ENDC}")
            else:
                print(f"{Colors.RED}[-] {file_path} missing{Colors.ENDC}")
                all_exist = False
        
        return all_exist
    
    def test_dependencies(self):
        """Тестирование зависимостей"""
        print(f"\n{Colors.YELLOW}[*] Testing dependencies...{Colors.ENDC}")
        
        dependencies = {
            "cmake": ["cmake", "--version"],
            "gcc": ["gcc", "--version"],
            "g++": ["g++", "--version"],
            "python3": ["python3", "--version"],
            "pip3": ["pip3", "--version"]
        }
        
        all_good = True
        for name, cmd in dependencies.items():
            try:
                subprocess.run(cmd, capture_output=True, check=True)
                print(f"{Colors.GREEN}[+] {name} is available{Colors.ENDC}")
            except (subprocess.CalledProcessError, FileNotFoundError):
                print(f"{Colors.RED}[-] {name} is not available{Colors.ENDC}")
                all_good = False
        
        return all_good
    
    def test_python_dependencies(self):
        """Тестирование Python зависимостей"""
        print(f"\n{Colors.YELLOW}[*] Testing Python dependencies...{Colors.ENDC}")
        
        requirements_file = self.server_dir / "requirements.txt"
        if not requirements_file.exists():
            print(f"{Colors.RED}[-] requirements.txt not found{Colors.ENDC}")
            return False
        
        try:
            with open(requirements_file, 'r') as f:
                requirements = f.readlines()
            
            all_installed = True
            for req in requirements:
                req = req.strip()
                if req and not req.startswith('#'):
                    try:
                        subprocess.run(["python3", "-c", f"import {req.split('>=')[0]}"], 
                                     capture_output=True, check=True)
                        print(f"{Colors.GREEN}[+] {req.split('>=')[0]} is installed{Colors.ENDC}")
                    except subprocess.CalledProcessError:
                        print(f"{Colors.RED}[-] {req.split('>=')[0]} is not installed{Colors.ENDC}")
                        all_installed = False
            
            return all_installed
            
        except Exception as e:
            print(f"{Colors.RED}[-] Error checking Python dependencies: {e}{Colors.ENDC}")
            return False
    
    def test_build_system(self):
        """Тестирование системы сборки"""
        print(f"\n{Colors.YELLOW}[*] Testing build system...{Colors.ENDC}")
        
        build_dir = self.project_root / "build"
        build_dir.mkdir(exist_ok=True)
        
        try:
            os.chdir(build_dir)
            
            # Тестируем cmake
            result = subprocess.run(["cmake", ".."], capture_output=True, text=True)
            if result.returncode == 0:
                print(f"{Colors.GREEN}[+] CMake configuration successful{Colors.ENDC}")
                return True
            else:
                print(f"{Colors.RED}[-] CMake configuration failed{Colors.ENDC}")
                print(f"{Colors.RED}Error: {result.stderr}{Colors.ENDC}")
                return False
                
        except Exception as e:
            print(f"{Colors.RED}[-] Error testing build system: {e}{Colors.ENDC}")
            return False
        finally:
            os.chdir(self.project_root)
    
    def test_configuration_files(self):
        """Тестирование файлов конфигурации"""
        print(f"\n{Colors.YELLOW}[*] Testing configuration files...{Colors.ENDC}")
        
        # Проверяем CMakeLists.txt
        cmake_file = self.project_root / "CMakeLists.txt"
        if cmake_file.exists():
            print(f"{Colors.GREEN}[+] CMakeLists.txt exists{Colors.ENDC}")
        else:
            print(f"{Colors.RED}[-] CMakeLists.txt missing{Colors.ENDC}")
            return False
        
        # Проверяем src/CMakeLists.txt
        src_cmake = self.project_root / "src" / "CMakeLists.txt"
        if src_cmake.exists():
            print(f"{Colors.GREEN}[+] src/CMakeLists.txt exists{Colors.ENDC}")
        else:
            print(f"{Colors.RED}[-] src/CMakeLists.txt missing{Colors.ENDC}")
            return False
        
        return True
    
    def test_source_code(self):
        """Базовое тестирование исходного кода"""
        print(f"\n{Colors.YELLOW}[*] Testing source code...{Colors.ENDC}")
        
        src_files = [
            "src/stager.cpp",
            "src/loader.cpp",
            "src/beacon.cpp",
            "src/persistence.cpp",
            "src/main.cpp",
            "src/shadow.h"
        ]
        
        all_good = True
        for src_file in src_files:
            file_path = self.project_root / src_file
            if file_path.exists():
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # Базовые проверки
                    if 'shadow.h' in content or '#include' in content:
                        print(f"{Colors.GREEN}[+] {src_file} looks good{Colors.ENDC}")
                    else:
                        print(f"{Colors.YELLOW}[!] {src_file} may have issues{Colors.ENDC}")
                        
                except Exception as e:
                    print(f"{Colors.RED}[-] Error reading {src_file}: {e}{Colors.ENDC}")
                    all_good = False
            else:
                print(f"{Colors.RED}[-] {src_file} not found{Colors.ENDC}")
                all_good = False
        
        return all_good
    
    def test_server_functionality(self):
        """Тестирование функциональности сервера"""
        print(f"\n{Colors.YELLOW}[*] Testing server functionality...{Colors.ENDC}")
        
        server_file = self.server_dir / "shadow_server.py"
        if not server_file.exists():
            print(f"{Colors.RED}[-] shadow_server.py not found{Colors.ENDC}")
            return False
        
        try:
            # Проверяем синтаксис Python файла
            result = subprocess.run(["python3", "-m", "py_compile", str(server_file)], 
                                  capture_output=True)
            if result.returncode == 0:
                print(f"{Colors.GREEN}[+] Server Python syntax is valid{Colors.ENDC}")
                return True
            else:
                print(f"{Colors.RED}[-] Server Python syntax error{Colors.ENDC}")
                return False
                
        except Exception as e:
            print(f"{Colors.RED}[-] Error testing server: {e}{Colors.ENDC}")
            return False
    
    def run_all_tests(self):
        """Запуск всех тестов"""
        print(f"{Colors.CYAN}{Colors.BOLD}ShadowC2 Toolkit Test Suite{Colors.ENDC}")
        print(f"{Colors.CYAN}=========================={Colors.ENDC}")
        
        tests = [
            ("File Structure", self.test_file_structure),
            ("Dependencies", self.test_dependencies),
            ("Python Dependencies", self.test_python_dependencies),
            ("Build System", self.test_build_system),
            ("Configuration Files", self.test_configuration_files),
            ("Source Code", self.test_source_code),
            ("Server Functionality", self.test_server_functionality)
        ]
        
        results = {}
        
        for test_name, test_func in tests:
            try:
                result = test_func()
                results[test_name] = result
            except Exception as e:
                print(f"{Colors.RED}[-] Test '{test_name}' failed with exception: {e}{Colors.ENDC}")
                results[test_name] = False
        
        # Выводим результаты
        print(f"\n{Colors.CYAN}{Colors.BOLD}Test Results{Colors.ENDC}")
        print(f"{Colors.CYAN}============{Colors.ENDC}")
        
        passed = 0
        total = len(tests)
        
        for test_name, result in results.items():
            status = f"{Colors.GREEN}PASSED{Colors.ENDC}" if result else f"{Colors.RED}FAILED{Colors.ENDC}"
            print(f"{test_name}: {status}")
            if result:
                passed += 1
        
        print(f"\n{Colors.CYAN}Total: {passed}/{total} tests passed{Colors.ENDC}")
        
        if passed == total:
            print(f"\n{Colors.GREEN}{Colors.BOLD}[+] All tests passed! Toolkit is ready for use.{Colors.ENDC}")
            return True
        else:
            print(f"\n{Colors.RED}{Colors.BOLD}[-] Some tests failed. Please check the issues above.{Colors.ENDC}")
            return False

def main():
    tester = ShadowC2Tester()
    return tester.run_all_tests()

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)