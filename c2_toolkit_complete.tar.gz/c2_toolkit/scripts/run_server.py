#!/usr/bin/env python3
"""
ShadowC2 Server Runner
Упрощенный запуск C2 сервера
"""

import os
import sys
import argparse
import subprocess
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description='ShadowC2 Server Runner')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind to')
    parser.add_argument('--port', type=int, default=8443, help='Port to bind to')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    parser.add_argument('--no-ssl', action='store_true', help='Disable SSL (for testing only)')
    
    args = parser.parse_args()
    
    # Определяем путь к серверу
    server_path = Path(__file__).parent.parent / "server" / "shadow_server.py"
    
    if not server_path.exists():
        print(f"Error: Server not found at {server_path}")
        print("Please run build script first: python scripts/build.py")
        sys.exit(1)
    
    # Формируем команду запуска
    cmd = ["python3", str(server_path)]
    
    if args.host != '0.0.0.0':
        cmd.extend(["--host", args.host])
    
    if args.port != 8443:
        cmd.extend(["--port", str(args.port)])
    
    if args.debug:
        cmd.append("--debug")
    
    # Запускаем сервер
    print(f"Starting ShadowC2 server...")
    print(f"Host: {args.host}")
    print(f"Port: {args.port}")
    print(f"Debug: {args.debug}")
    
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        print("\nServer stopped.")

if __name__ == "__main__":
    main()